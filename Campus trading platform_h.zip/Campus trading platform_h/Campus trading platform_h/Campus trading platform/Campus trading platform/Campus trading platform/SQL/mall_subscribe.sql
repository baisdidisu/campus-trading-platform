-- 商城分类订阅表
CREATE TABLE IF NOT EXISTS `mall_subscribe` (
  `subscribe_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `category_id` int(11) NOT NULL COMMENT '分类ID(对应sort一级分类)',
  `modified` datetime DEFAULT NULL,
  `display` int(11) DEFAULT '1' COMMENT '1显示 0删除',
  PRIMARY KEY (`subscribe_id`),
  KEY `idx_user_category` (`user_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

