-- 1. 创建求购订阅表（buy_subscribe）
DROP TABLE IF EXISTS `buy_subscribe`;
CREATE TABLE `buy_subscribe` (
    `subscribe_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订阅ID',
    `user_id` int(11) NOT NULL COMMENT '用户ID',
    `category_id` int(11) NOT NULL COMMENT '分类ID（对应shopinformation的sort字段）',
    `modified` datetime DEFAULT NULL COMMENT '修改时间',
    `display` int(11) NOT NULL DEFAULT '1' COMMENT '是否有效：0=取消, 1=有效',
    PRIMARY KEY (`subscribe_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_category_id` (`category_id`),
    UNIQUE KEY `uk_user_category` (`user_id`, `category_id`, `display`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='求购订阅表';

-- 2. 如果消息表已存在，则添加新字段
-- 注意：MySQL 5.7以下版本不支持 IF NOT EXISTS，需要手动检查字段是否存在
-- 方式一：MySQL 8.0+ 支持 IF NOT EXISTS
ALTER TABLE `message`
ADD COLUMN IF NOT EXISTS `message_type` int(11) NOT NULL DEFAULT '1' COMMENT '消息类型：1=交易, 2=价格提醒, 3=过期提醒' AFTER `content`,
ADD COLUMN IF NOT EXISTS `bargain_type` varchar(50) DEFAULT NULL COMMENT '议价类型（如：少5元、包邮等）' AFTER `message_type`,
ADD COLUMN IF NOT EXISTS `related_id` int(11) DEFAULT NULL COMMENT '关联ID（商品ID或求购ID）' AFTER `bargain_type`,
ADD COLUMN IF NOT EXISTS `is_read` int(11) NOT NULL DEFAULT '0' COMMENT '是否已读：0=未读, 1=已读' AFTER `related_id`;

