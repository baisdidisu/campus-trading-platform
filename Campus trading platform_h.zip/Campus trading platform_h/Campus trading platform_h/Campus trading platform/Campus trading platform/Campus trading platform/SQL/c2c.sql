SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admininformation
-- ----------------------------
DROP TABLE IF EXISTS `admininformation`;
CREATE TABLE `admininformation` (
                                    `id` int(11) NOT NULL,
                                    `ano` char(12) NOT NULL,
                                    `password` char(24) NOT NULL,
                                    `modified` datetime DEFAULT NULL,
                                    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admininformation
-- ----------------------------

-- ----------------------------
-- Table structure for adminoperation
-- ----------------------------
DROP TABLE IF EXISTS `adminoperation`;
CREATE TABLE `adminoperation` (
                                  `id` int(11) NOT NULL,
                                  `aid` int(11) NOT NULL,
                                  `modified` datetime DEFAULT NULL,
                                  `operation` varchar(255) NOT NULL,
                                  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of adminoperation
-- ----------------------------

-- ----------------------------
-- Table structure for allkinds
-- ----------------------------
DROP TABLE IF EXISTS `allkinds`;
CREATE TABLE `allkinds` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `name` varchar(50) NOT NULL,
                            `modified` datetime DEFAULT NULL,
                            PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of allkinds
-- ----------------------------
INSERT INTO `allkinds` VALUES ('1', '数码科技', '2025-12-28 13:28:20');
INSERT INTO `allkinds` VALUES ('2', '影音家电', '2025-12-28 13:28:23');
INSERT INTO `allkinds` VALUES ('3', '鞋服配饰', '2025-12-28 13:28:26');
INSERT INTO `allkinds` VALUES ('4', '运动代步', '2025-12-28 13:28:28');
INSERT INTO `allkinds` VALUES ('5', '书籍文具', '2025-12-28 13:28:31');
INSERT INTO `allkinds` VALUES ('6', '其他', '2025-12-28 13:28:41');

-- ----------------------------
-- Table structure for boughtshop
-- ----------------------------
DROP TABLE IF EXISTS `boughtshop`;
CREATE TABLE `boughtshop` (
                              `id` int(11) NOT NULL AUTO_INCREMENT,
                              `modified` datetime DEFAULT NULL,
                              `state` int(11) NOT NULL,
                              `uid` int(11) NOT NULL,
                              `sid` int(11) NOT NULL,
                              `quantity` int(11) NOT NULL,
                              PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of boughtshop
-- ----------------------------

-- ----------------------------
-- Table structure for classification
-- ----------------------------
DROP TABLE IF EXISTS `classification`;
CREATE TABLE `classification` (
                                  `id` int(11) NOT NULL AUTO_INCREMENT,
                                  `name` varchar(50) NOT NULL,
                                  `modified` datetime DEFAULT NULL,
                                  `aid` int(11) NOT NULL,
                                  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of classification
-- ----------------------------
INSERT INTO `classification` VALUES ('1', '手机', null, '1');
INSERT INTO `classification` VALUES ('2', '相机', null, '1');
INSERT INTO `classification` VALUES ('3', '电脑', null, '1');
INSERT INTO `classification` VALUES ('4', '家电', null, '2');
INSERT INTO `classification` VALUES ('5', '影音', null, '2');
INSERT INTO `classification` VALUES ('6', '女装', null, '3');
INSERT INTO `classification` VALUES ('7', '男装', null, '3');
INSERT INTO `classification` VALUES ('8', '女鞋', null, '3');
INSERT INTO `classification` VALUES ('9', '男鞋', null, '3');
INSERT INTO `classification` VALUES ('10', '箱包', null, '3');
INSERT INTO `classification` VALUES ('11', '手表', null, '3');
INSERT INTO `classification` VALUES ('12', '器材', null, '4');
INSERT INTO `classification` VALUES ('13', '代步', null, '4');
INSERT INTO `classification` VALUES ('14', '修养', null, '5');
INSERT INTO `classification` VALUES ('15', '专业', null, '5');
INSERT INTO `classification` VALUES ('16', '文具', null, '5');
INSERT INTO `classification` VALUES ('17', '其他', null, '6');

-- ----------------------------
-- Table structure for goodscar
-- ----------------------------
DROP TABLE IF EXISTS `goodscar`;
CREATE TABLE `goodscar` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `modified` datetime DEFAULT NULL,
                            `sid` int(11) NOT NULL,
                            `uid` int(11) NOT NULL,
                            `quantity` int(11) NOT NULL,
                            `display` int(11) NOT NULL DEFAULT '1',
                            PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goodscar
-- ----------------------------
INSERT INTO `goodscar` VALUES ('1', '2025-12-22 21:57:31', '2', '7', '2', '1');
INSERT INTO `goodscar` VALUES ('2', '2025-12-23 11:45:09', '92', '7', '1', '1');
INSERT INTO `goodscar` VALUES ('3', '2025-12-26 14:23:29', '1095', '7', '1', '1');
INSERT INTO `goodscar` VALUES ('4', '2025-12-29 15:35:13', '1097', '9', '1', '1');

-- ----------------------------
-- Table structure for goodsoforderform
-- ----------------------------
DROP TABLE IF EXISTS `goodsoforderform`;
CREATE TABLE `goodsoforderform` (
                                    `id` int(11) NOT NULL AUTO_INCREMENT,
                                    `ofid` int(11) NOT NULL,
                                    `sid` int(11) NOT NULL,
                                    `modified` datetime DEFAULT NULL,
                                    `quantity` int(11) NOT NULL,
                                    `display` int(11) NOT NULL DEFAULT '1',
                                    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goodsoforderform
-- ----------------------------

-- ----------------------------
-- Table structure for orderform
-- ----------------------------
DROP TABLE IF EXISTS `orderform`;
CREATE TABLE `orderform` (
                             `id` int(11) NOT NULL AUTO_INCREMENT,
                             `modified` datetime DEFAULT NULL,
                             `display` int(11) NOT NULL DEFAULT '1',
                             `uid` int(11) NOT NULL,
                             `address` varchar(255) NOT NULL,
                             `context` varchar(255) DEFAULT NULL,
                             PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderform
-- ----------------------------

-- ----------------------------
-- Table structure for shopcar
-- ----------------------------
DROP TABLE IF EXISTS `shopcar`;
CREATE TABLE `shopcar` (
                           `id` int(11) NOT NULL AUTO_INCREMENT,
                           `modified` datetime DEFAULT NULL,
                           `display` int(11) NOT NULL DEFAULT '1',
                           `uid` int(11) NOT NULL,
                           PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shopcar
-- ----------------------------

-- ----------------------------
-- Table structure for shopcontext
-- ----------------------------
DROP TABLE IF EXISTS `shopcontext`;
CREATE TABLE `shopcontext` (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `modified` datetime DEFAULT NULL,
                               `sid` int(11) NOT NULL,
                               `context` varchar(255) NOT NULL,
                               `display` int(11) NOT NULL DEFAULT '1',
                               `uid` int(11) NOT NULL DEFAULT '1',
                               PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shopcontext
-- ----------------------------
INSERT INTO `shopcontext` VALUES ('1', '2025-12-11 16:09:35', '92', '今天是个哈日子', '1', '1');
INSERT INTO `shopcontext` VALUES ('2', '2025-12-21 16:38:44', '92', 'test', '1', '1');
INSERT INTO `shopcontext` VALUES ('3', '2025-12-21 19:29:25', '92', '好的东西就要积累', '1', '7');
INSERT INTO `shopcontext` VALUES ('4', '2025-12-21 19:30:12', '92', '好的东西就要积累', '1', '7');
INSERT INTO `shopcontext` VALUES ('5', '2025-12-21 19:33:48', '92', '好的东西', '1', '7');
INSERT INTO `shopcontext` VALUES ('6', '2025-12-21 19:47:02', '5', '111111', '1', '7');
INSERT INTO `shopcontext` VALUES ('7', '2025-12-21 19:47:50', '5', '1111', '1', '7');
INSERT INTO `shopcontext` VALUES ('8', '2025-12-21 19:48:49', '5', '就看见看看', '1', '7');
INSERT INTO `shopcontext` VALUES ('9', '2025-12-21 19:50:41', '92', '嘻嘻', '1', '7');
INSERT INTO `shopcontext` VALUES ('10', '2025-12-22 22:07:14', '88', '1111', '1', '7');
INSERT INTO `shopcontext` VALUES ('11', '2025-12-23 22:19:19', '69', '11111', '1', '7');
INSERT INTO `shopcontext` VALUES ('12', '2025-12-26 13:54:13', '1096', '11111', '1', '7');
INSERT INTO `shopcontext` VALUES ('13', '2025-12-29 15:52:52', '1095', 'test', '1', '9');
INSERT INTO `shopcontext` VALUES ('14', '2025-12-29 15:54:07', '1095', 'test44', '1', '9');

-- ----------------------------
-- Table structure for shopinformation
-- ----------------------------
DROP TABLE IF EXISTS `shopinformation`;
CREATE TABLE `shopinformation` (
                                   `id` int(11) NOT NULL AUTO_INCREMENT,
                                   `modified` datetime DEFAULT NULL,
                                   `name` varchar(50) NOT NULL,
                                   `level` int(11) NOT NULL,
                                   `remark` varchar(255) NOT NULL,
                                   `price` decimal(10,2) NOT NULL,
                                   `sort` int(11) NOT NULL,
                                   `display` int(11) NOT NULL DEFAULT '1',
                                   `quantity` int(11) NOT NULL,
                                   `transaction` int(11) NOT NULL DEFAULT '1',
                                   `sales` int(11) DEFAULT '0',
                                   `uid` int(11) NOT NULL,
                                   `image` varchar(255) DEFAULT NULL,
                                   `thumbnails` varchar(255) DEFAULT NULL,
                                   PRIMARY KEY (`id`),
                                   KEY `index_uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1098 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shopinformation
-- ----------------------------
INSERT INTO `shopinformation` VALUES ('1', null, 'c', '4', 'sdf', '12.00', '33', '1', '3', '0', '1', '1', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('2', null, '算法导论', '9', '很好的一本书', '70.00', '86', '1', '1', '1', '2', '1', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('3', null, '爱我的人', '3', '来自cstp的爱', '12.00', '3', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('4', null, '729乒乓球拍', '5', '来自cstp的爱,QQtest', '77.56', '67', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('5', null, '苹果6S', '5', '来自cstp的爱,QQtest', '5000.00', '1', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('6', null, '三星5A', '5', '来自cstp的爱,QQtest', '4000.12', '2', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('7', null, '小米6', '7', '来自cstp的爱,QQtest', '3000.56', '3', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('8', null, '华为8', '7', '来自cstp的爱,QQtest', '3000.57', '4', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('9', null, '中兴8', '7', '来自cstp的爱,QQtest', '3000.57', '5', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('10', null, '联系9', '7', '来自cstp的爱,QQtest', '4654.00', '6', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('11', null, '魅族7S', '7', '来自cstp的爱,QQtest', '4434.00', '7', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('12', null, '索爱8', '7', '来自cstp的爱,QQtest', '4434.33', '8', '1', '3', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('13', null, '苹果耳机', '7', '来自cstp的爱,QQtest', '100.00', '9', '1', '34', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('14', null, '普通相机10', '7', '来自cstp的爱,QQtest', '5100.00', '10', '1', '34', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('15', null, '贾尼单反', '5', '来自cstp的爱,QQtest', '5100.00', '11', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('16', null, '其他东东', '5', '来自cstp的爱,QQtest', '5100.00', '12', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('17', null, '笔记本宏碁13', '8', '来自cstp的爱,QQtest', '5100.00', '13', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('18', null, '苹果平板5', '8', '来自cstp的爱,QQtest', '5100.00', '14', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('19', null, 'HP台式电脑', '8', '来自cstp的爱,QQtest', '4100.00', '15', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('20', null, '戴尔显示器', '8', '来自cstp的爱,QQtest', '1100.00', '16', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('21', null, '雷蛇鼠标', '8', '来自cstp的爱,QQtest', '1100.00', '17', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('22', null, '雷神键盘', '8', '来自cstp的爱,QQtest', '1100.00', '18', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('23', null, 'U盘金士顿64G', '8', '来自cstp的爱,QQtest', '200.00', '19', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('24', null, '爱国者移动硬盘1T', '8', '来自cstp的爱,QQtest', '500.90', '20', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('25', null, '爱？', '8', '来自cstp的爱,QQtest', '500.90', '21', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('26', null, '小天鹅洗衣机', '8', '来自cstp的爱,QQtest', '700.00', '22', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('27', null, '饮水机', '8', '来自cstp的爱,QQtest', '700.00', '23', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('28', null, '吹风机', '8', '来自cstp的爱,QQtest', '40.00', '24', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('29', null, '剃须刀', '8', '来自cstp的爱,QQtest', '40.00', '25', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('30', null, '小型风扇', '8', '来自cstp的爱,QQtest', '40.00', '26', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('31', null, '煮蛋器', '8', '来自cstp的爱,QQtest', '40.00', '27', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('32', null, '电磁炉 美的', '8', '来自cstp的爱,QQtest', '100.00', '28', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('33', null, '电饭煲格力', '8', '来自cstp的爱,QQtest', '100.00', '29', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('34', null, '超级耳机', '8', '来自cstp的爱,QQtest', '100.00', '30', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('35', null, '很好的音响', '8', '来自cstp的爱,QQtest', '120.58', '31', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('36', null, '功放？', '8', '来自cstp的爱,QQtest', '120.58', '32', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('37', null, '低音炮', '8', '来自cstp的爱,QQtest', '120.58', '33', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('38', null, '麦克风', '8', '来自cstp的爱,QQtest', '120.58', '34', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('39', null, '超好看的上衣', '8', '来自cstp的爱,QQtest', '120.58', '35', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('40', null, '炫酷短裤', '8', '来自cstp的爱,QQtest', '120.58', '36', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('41', null, '百褶裙', '8', '来自cstp的爱,QQtest', '55.00', '37', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('42', null, '短上衣', '8', '来自cstp的爱,QQtest', '55.00', '38', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('43', null, '长裤', '8', '来自cstp的爱,QQtest', '55.00', '39', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('44', null, '运动鞋耐克', '8', '来自cstp的爱,QQtest', '1200.00', '40', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('45', null, '皮鞋安踏', '8', '来自cstp的爱,QQtest', '200.00', '41', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('46', null, '帆布鞋', '8', '来自cstp的爱,QQtest', '200.00', '45', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('47', null, '球鞋', '8', '来自cstp的爱,QQtest', '200.00', '46', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('48', null, '板鞋', '8', '来自cstp的爱,QQtest', '200.00', '47', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('49', null, '男生运动鞋', '8', '来自cstp的爱,QQtest', '200.00', '49', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('50', null, '男生皮鞋', '8', '来自cstp的爱,QQtest', '500.00', '50', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('51', null, '男生帆布鞋', '8', '来自cstp的爱,QQtest', '10.00', '51', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('52', null, '男生球鞋', '8', '来自cstp的爱,QQtest', '1000.00', '52', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('53', null, '背包VL', '8', '来自cstp的爱,QQtest', '1000.00', '55', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('54', null, '超级旅行包', '8', '来自cstp的爱,QQtest', '200.00', '56', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('55', null, '呆板机械表', '8', '来自cstp的爱,QQtest', '400.00', '58', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('56', null, '好看的石英表', '8', '来自cstp的爱,QQtest', '400.00', '59', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('57', null, '一般电子版', '8', '来自cstp的爱,QQtest', '100.00', '60', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('58', null, '足球', '8', '来自cstp的爱,QQtest', '100.00', '62', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('59', null, '羽毛球拍', '8', '来自cstp的爱,QQtest', '100.00', '63', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('60', null, '网球拍', '8', '来自cstp的爱,QQtest', '100.00', '64', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('61', null, '篮球', '8', '来自cstp的爱,QQtest', '100.00', '65', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('62', null, '滑轮', '8', '来自cstp的爱,QQtest', '100.00', '66', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('63', null, '乒乓球拍', '8', '来自cstp的爱,QQtest', '100.00', '67', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('64', null, '滑板', '8', '来自cstp的爱,QQtest', '100.00', '68', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('65', null, '自行车', '8', '来自cstp的爱,QQtest', '300.00', '70', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('66', null, '电动车', '8', '来自cstp的爱,QQtest', '800.85', '71', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('67', null, '傲慢与偏见', '8', '来自cstp的爱,QQtest', '20.00', '73', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('68', null, '海贼王漫画', '8', '来自cstp的爱,QQtest', '20.00', '74', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('69', null, '爱尔兰的野马', '8', '来自cstp的爱,QQtest', '20.00', '75', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('70', null, '生命的起源', '8', '来自cstp的爱,QQtest', '25.00', '77', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('71', null, '神奇的化学变化', '8', '来自cstp的爱,QQtest', '25.00', '78', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('72', null, '黑洞与白洞', '8', '来自cstp的爱,QQtest', '51.00', '79', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('73', null, '诗经全集', '8', '来自cstp的爱,QQtest', '51.00', '80', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('74', null, '小语种-莫拉语', '8', '来自cstp的爱,QQtest', '51.00', '81', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('75', null, '真：五元十次方程详细解法', '8', '来自cstp的爱,QQtest', '51.00', '82', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('76', null, '国家的安定', '8', '来自cstp的爱,QQtest', '51.00', '83', '1', '4', '1', '0', '4', '\\image/eW5NE6CM121494763475193.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('77', null, '曼陀罗消亡史', '8', '来自cstp的爱,QQtest', '51.00', '84', '1', '4', '1', '0', '4', '\\image/978P2M7w0ExYqmzci0aX20170105.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('78', null, '神奇的广东', '8', '来自cstp的爱,QQtest', '51.00', '85', '1', '4', '1', '0', '4', '\\image/978P2M7w0ExYqmzci0aX20170105.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('79', null, 'Spring实战', '8', '来自cstp的爱,QQtest', '51.00', '86', '1', '4', '1', '0', '4', '\\image/1.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('80', null, 'ACD画图', '8', '来自cstp的爱,QQtest', '51.00', '87', '1', '4', '1', '0', '4', '\\image/aug1NiTT40tXd3Zy1ZWL20161215.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('81', null, '怎么建房子容易倒塌', '8', '来自cstp的爱,QQtest', '51.00', '88', '1', '4', '1', '0', '4', '\\image/bvmE7d8698C3VdjSMjHm20161225.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('82', null, '算法的艺术', '8', '来自cstp的爱,QQtest', '51.00', '89', '1', '4', '1', '0', '4', '\\image/rzNz7r8XkK8Q97Ki42FB20161214.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('83', null, '狼毫笔', '8', '来自cstp的爱,QQtest，机械，这个容易受欧尚的', '51.00', '91', '1', '4', '1', '0', '4', '\\image/langhaobi.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('84', null, '景德镇陶瓷', '8', '来自cstp的爱,QQtest，机械，这个容易受欧尚的', '522225.50', '92', '1', '4', '1', '0', '4', '\\image/jingdezheng.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('87', null, '华为P10', '8', '来自cstp的爱,QQtest，机械，这个容易受欧尚的', '525.50', '1', '1', '4', '1', '0', '4', '\\image/huawei.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('88', null, '苹果6SPLUS', '8', '来自cstp的爱,QQtest，机械，这个容易受欧尚的？', '525.50', '1', '1', '4', '1', '0', '4', '\\image/apple6s.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('89', null, '小米5', '8', '来自cstp的爱,QQtest，机械，这个容易受欧尚的？', '525.50', '1', '1', '4', '1', '0', '4', 'image/xiaomi5.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('90', null, '苹果6S', '8', '来自cstp的爱,QQtest，机械，这个容易受欧尚的？', '5525.50', '1', '1', '4', '1', '0', '4', 'image/apple6s.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('91', null, '月球下的人', '7', 'cstp1103', '34.00', '73', '1', '1', '1', '0', '7', 'image/yourname.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('92', null, '傲慢与偏见', '9', '来自cstp的爱', '24.00', '73', '1', '1', '1', '0', '7', 'image\\PorRmD0JDZ1495278394532.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('93', null, '百年孤独', '3', '看上的请联系我，QQ：test，微信：test', '203.45', '1', '1', '9', '1', '0', '19', '/image/QyBHYiMfYQ4XZFCqxEv0.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('94', null, '算法导论', '7', '看上的请联系我，QQ：test，微信：test', '89.00', '86', '1', '1', '1', '0', '7', 'image\\hPWMF78VWv1495700233684.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('95', null, '意林', '10', '看上的请联系我，QQ：test，微信：test', '45.00', '73', '1', '1', '1', '0', '7', 'image\\lXQypgCAQa1495700291317.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('96', null, '苹果6', '7', '看上的请联系我，QQ：test，微信：test', '4500.50', '1', '1', '1', '1', '0', '7', 'image\\2Y9gArO60W1495700684738.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');
INSERT INTO `shopinformation` VALUES ('97', null, 'cstp的爱', '7', '有意者联系QQtest', '4422.00', '94', '1', '1', '1', '0', '7', 'image\\zrTpmZACwf1496368854318.jpg', '/images/thumbnails/IrFMeAQeua1496368854318.jpg');

-- ----------------------------
-- Table structure for shoppicture
-- ----------------------------
DROP TABLE IF EXISTS `shoppicture`;
CREATE TABLE `shoppicture` (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `modified` datetime DEFAULT NULL,
                               `sid` int(11) NOT NULL,
                               `picture` varchar(200) NOT NULL,
                               `display` int(11) NOT NULL DEFAULT '1',
                               PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shoppicture
-- ----------------------------
INSERT INTO `shoppicture` VALUES ('1', null, '1', '/image/1.jpg', '1');
INSERT INTO `shoppicture` VALUES ('2', null, '2', '\\image/eW5NE6CM121494763475193.jpg', '1');
INSERT INTO `shoppicture` VALUES ('3', null, '3', '\\image/02.jpg', '1');
INSERT INTO `shoppicture` VALUES ('4', null, '4', '\\image\\htEZLneu1d1494764039225.jpg', '1');
INSERT INTO `shoppicture` VALUES ('5', null, '5', '\\image\\OAkysrUmZs1494764129394.jpg', '1');

-- ----------------------------
-- Table structure for specifickinds
-- ----------------------------
DROP TABLE IF EXISTS `specifickinds`;
CREATE TABLE `specifickinds` (
                                 `id` int(11) NOT NULL AUTO_INCREMENT,
                                 `name` varchar(50) NOT NULL,
                                 `modified` datetime DEFAULT NULL,
                                 `cid` int(11) NOT NULL,
                                 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of specifickinds
-- ----------------------------
INSERT INTO `specifickinds` VALUES ('1', '苹果', null, '1');
INSERT INTO `specifickinds` VALUES ('2', '三星', null, '1');
INSERT INTO `specifickinds` VALUES ('3', '小米', null, '1');
INSERT INTO `specifickinds` VALUES ('4', '华为', null, '1');
INSERT INTO `specifickinds` VALUES ('5', '中兴', null, '1');
INSERT INTO `specifickinds` VALUES ('6', '联想', null, '1');
INSERT INTO `specifickinds` VALUES ('7', '魅族', null, '1');
INSERT INTO `specifickinds` VALUES ('8', '其他', null, '1');
INSERT INTO `specifickinds` VALUES ('9', '耳机', null, '1');
INSERT INTO `specifickinds` VALUES ('10', '普通相机', null, '2');
INSERT INTO `specifickinds` VALUES ('11', '单反', null, '2');
INSERT INTO `specifickinds` VALUES ('12', '其他', null, '2');
INSERT INTO `specifickinds` VALUES ('13', '笔记本', null, '3');
INSERT INTO `specifickinds` VALUES ('14', '平板电脑', null, '3');
INSERT INTO `specifickinds` VALUES ('15', '台式机', null, '3');
INSERT INTO `specifickinds` VALUES ('16', '显示器', null, '3');
INSERT INTO `specifickinds` VALUES ('17', '鼠标', null, '3');
INSERT INTO `specifickinds` VALUES ('18', '硬盘', null, '3');
INSERT INTO `specifickinds` VALUES ('19', 'U盘', null, '3');
INSERT INTO `specifickinds` VALUES ('20', '移动硬盘', null, '3');
INSERT INTO `specifickinds` VALUES ('21', '其他', null, '3');
INSERT INTO `specifickinds` VALUES ('22', '洗衣机', null, '4');
INSERT INTO `specifickinds` VALUES ('23', '饮水机', null, '4');
INSERT INTO `specifickinds` VALUES ('24', '吹风机', null, '4');
INSERT INTO `specifickinds` VALUES ('25', '剃须刀', null, '4');
INSERT INTO `specifickinds` VALUES ('26', '风扇', null, '4');
INSERT INTO `specifickinds` VALUES ('27', '煮蛋器', null, '4');
INSERT INTO `specifickinds` VALUES ('28', '电磁炉', null, '4');
INSERT INTO `specifickinds` VALUES ('29', '电饭煲', null, '4');
INSERT INTO `specifickinds` VALUES ('30', '其他', null, '4');
INSERT INTO `specifickinds` VALUES ('31', '耳机', null, '5');
INSERT INTO `specifickinds` VALUES ('32', '音响', null, '5');
INSERT INTO `specifickinds` VALUES ('33', '功放', null, '5');
INSERT INTO `specifickinds` VALUES ('34', '低音炮', null, '5');
INSERT INTO `specifickinds` VALUES ('35', '麦克风', null, '5');
INSERT INTO `specifickinds` VALUES ('36', '上衣', null, '6');
INSERT INTO `specifickinds` VALUES ('37', '裤子', null, '6');
INSERT INTO `specifickinds` VALUES ('38', '裙子', null, '6');
INSERT INTO `specifickinds` VALUES ('39', '其他', null, '6');
INSERT INTO `specifickinds` VALUES ('40', '上衣', null, '7');
INSERT INTO `specifickinds` VALUES ('41', '裤子', null, '7');
INSERT INTO `specifickinds` VALUES ('42', '其他', null, '7');
INSERT INTO `specifickinds` VALUES ('43', '运动鞋', null, '8');
INSERT INTO `specifickinds` VALUES ('44', '皮鞋', null, '8');
INSERT INTO `specifickinds` VALUES ('45', '帆布鞋', null, '8');
INSERT INTO `specifickinds` VALUES ('46', '球鞋', null, '8');
INSERT INTO `specifickinds` VALUES ('47', '板鞋', null, '8');
INSERT INTO `specifickinds` VALUES ('48', '其他', null, '8');
INSERT INTO `specifickinds` VALUES ('49', '运动鞋', null, '9');
INSERT INTO `specifickinds` VALUES ('50', '皮鞋', '2025-12-10 21:53:20', '9');
INSERT INTO `specifickinds` VALUES ('51', '帆布鞋', '2025-12-10 21:53:23', '9');
INSERT INTO `specifickinds` VALUES ('52', '球鞋', '2025-12-10 21:53:26', '9');
INSERT INTO `specifickinds` VALUES ('53', '板鞋', '2025-12-10 21:53:28', '9');
INSERT INTO `specifickinds` VALUES ('54', '其他', '2025-12-10 21:53:30', '9');
INSERT INTO `specifickinds` VALUES ('55', '背包', null, '10');
INSERT INTO `specifickinds` VALUES ('56', '旅行箱', null, '10');
INSERT INTO `specifickinds` VALUES ('57', '其他', null, '10');
INSERT INTO `specifickinds` VALUES ('58', '机械表', null, '11');
INSERT INTO `specifickinds` VALUES ('59', '石英表', null, '11');
INSERT INTO `specifickinds` VALUES ('60', '电子表', null, '11');
INSERT INTO `specifickinds` VALUES ('61', '其他', null, '11');
INSERT INTO `specifickinds` VALUES ('62', '足球', null, '12');
INSERT INTO `specifickinds` VALUES ('63', '羽毛球拍', null, '12');
INSERT INTO `specifickinds` VALUES ('64', '网球拍', null, '12');
INSERT INTO `specifickinds` VALUES ('65', '篮球', null, '12');
INSERT INTO `specifickinds` VALUES ('66', '滑轮', null, '12');
INSERT INTO `specifickinds` VALUES ('67', '乒乓球拍', null, '12');
INSERT INTO `specifickinds` VALUES ('68', '滑板', null, '12');
INSERT INTO `specifickinds` VALUES ('69', '其他', null, '12');
INSERT INTO `specifickinds` VALUES ('70', '自行车', null, '13');
INSERT INTO `specifickinds` VALUES ('71', '电动车', null, '13');
INSERT INTO `specifickinds` VALUES ('72', '其他', null, '13');
INSERT INTO `specifickinds` VALUES ('73', '文学', null, '14');
INSERT INTO `specifickinds` VALUES ('74', '漫画', null, '14');
INSERT INTO `specifickinds` VALUES ('75', '小说', null, '14');
INSERT INTO `specifickinds` VALUES ('76', '其他', null, '14');
INSERT INTO `specifickinds` VALUES ('77', '生物', null, '15');
INSERT INTO `specifickinds` VALUES ('78', '化学', null, '15');
INSERT INTO `specifickinds` VALUES ('79', '物理', null, '15');
INSERT INTO `specifickinds` VALUES ('80', '语文', null, '15');
INSERT INTO `specifickinds` VALUES ('81', '外语', null, '15');
INSERT INTO `specifickinds` VALUES ('82', '数学', null, '15');
INSERT INTO `specifickinds` VALUES ('83', '政治', null, '15');
INSERT INTO `specifickinds` VALUES ('84', '历史', null, '15');
INSERT INTO `specifickinds` VALUES ('85', '地理', null, '15');
INSERT INTO `specifickinds` VALUES ('86', '计算机', null, '15');
INSERT INTO `specifickinds` VALUES ('87', '机械', null, '15');
INSERT INTO `specifickinds` VALUES ('88', '土木', null, '15');
INSERT INTO `specifickinds` VALUES ('89', '艺术', null, '15');
INSERT INTO `specifickinds` VALUES ('90', '其他', null, '15');
INSERT INTO `specifickinds` VALUES ('91', '笔', null, '16');
INSERT INTO `specifickinds` VALUES ('92', '其他', null, '16');
INSERT INTO `specifickinds` VALUES ('93', '其他', null, '5');
INSERT INTO `specifickinds` VALUES ('94', '其他', null, '17');

-- ----------------------------
-- Table structure for usercollection
-- ----------------------------
DROP TABLE IF EXISTS `usercollection`;
CREATE TABLE `usercollection` (
                                  `id` int(11) NOT NULL AUTO_INCREMENT,
                                  `modified` datetime DEFAULT NULL,
                                  `uid` int(11) NOT NULL,
                                  `sid` int(11) NOT NULL,
                                  `display` int(11) NOT NULL DEFAULT '1',
                                  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of usercollection
-- ----------------------------

-- ----------------------------
-- Table structure for userinformation
-- ----------------------------
DROP TABLE IF EXISTS `userinformation`;
CREATE TABLE `userinformation` (
                                   `id` int(11) NOT NULL AUTO_INCREMENT,
                                   `modified` datetime DEFAULT NULL,
                                   `username` varchar(50) NOT NULL,
                                   `phone` char(11) NOT NULL,
                                   `realname` varchar(50) DEFAULT NULL,
                                   `clazz` varchar(50) DEFAULT NULL,
                                   `sno` char(12) DEFAULT NULL,
                                   `dormitory` varchar(50) DEFAULT NULL,
                                   `gender` char(2) DEFAULT NULL,
                                   `createtime` datetime DEFAULT NULL,
                                   `avatar` varchar(200) DEFAULT NULL,
                                   PRIMARY KEY (`id`),
                                   UNIQUE KEY `index_id` (`id`) USING BTREE,
                                   KEY `selectByPhone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userinformation
-- ----------------------------
INSERT INTO `userinformation` VALUES ('1', '2025-12-28 13:56:04', 'cstp', '123', null, null, null, null, null, '2025-12-28 13:56:04', null);
INSERT INTO `userinformation` VALUES ('2', '2025-12-28 14:00:13', '111', '1234', null, null, null, null, null, '2025-12-28 14:00:14', null);
INSERT INTO `userinformation` VALUES ('3', '2025-12-28 14:55:28', '111', '122', null, null, null, null, null, '2025-12-28 14:55:28', null);
INSERT INTO `userinformation` VALUES ('4', '2025-12-28 15:00:11', '爱我的人1', '124', null, null, null, null, null, '2025-12-28 15:00:11', null);
INSERT INTO `userinformation` VALUES ('5', '2025-12-28 15:00:45', '爱我的人2', '125', null, null, null, null, null, '2025-12-28 15:00:45', null);
INSERT INTO `userinformation` VALUES ('6', '2025-12-28 15:01:13', '爱我的人3', '126', null, null, null, null, null, '2025-12-28 15:01:13', null);
INSERT INTO `userinformation` VALUES ('7', '2025-12-19 14:43:01', 'cstp1103', '127', '吴*', '信', '3', '9407', '男', '2025-12-20 15:14:14', '');
INSERT INTO `userinformation` VALUES ('8', '2025-12-20 22:31:08', 'cstp1103', '128', null, null, null, null, null, '2025-12-20 22:31:03', null);
INSERT INTO `userinformation` VALUES ('9', '2025-12-29 15:34:18', 'test', '129', null, null, null, null, null, '2025-12-29 15:34:17', null);

-- ----------------------------
-- Table structure for userpassword
-- ----------------------------
DROP TABLE IF EXISTS `userpassword`;
CREATE TABLE `userpassword` (
                                `id` int(11) NOT NULL AUTO_INCREMENT,
                                `modified` datetime DEFAULT NULL,
                                `password` varchar(50) NOT NULL,
                                `uid` int(11) NOT NULL,
                                PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userpassword
-- ----------------------------
INSERT INTO `userpassword` VALUES ('1', '2025-12-28 13:56:05', 'e10adc3949ba59abbe56e057f20f883e', '1');
INSERT INTO `userpassword` VALUES ('2', '2025-12-20 22:00:49', 'e10adc3949ba59abbe56e057f20f883e', '2');
INSERT INTO `userpassword` VALUES ('3', '2025-12-28 14:55:29', 'e10adc3949ba59abbe56e057f20f883e', '3');
INSERT INTO `userpassword` VALUES ('4', '2025-12-28 15:00:11', 'e10adc3949ba59abbe56e057f20f883e', '4');
INSERT INTO `userpassword` VALUES ('5', '2025-12-28 15:00:45', 'e10adc3949ba59abbe56e057f20f883e', '5');
INSERT INTO `userpassword` VALUES ('6', '2025-12-28 15:01:13', 'e10adc3949ba59abbe56e057f20f883e', '6');
INSERT INTO `userpassword` VALUES ('7', '2025-12-26 13:33:49', 'e10adc3949ba59abbe56e057f20f883e', '7');
INSERT INTO `userpassword` VALUES ('8', '2025-12-20 22:31:17', 'e10adc3949ba59abbe56e057f20f883e', '8');
INSERT INTO `userpassword` VALUES ('9', '2025-12-29 15:34:23', 'e10adc3949ba59abbe56e057f20f883e', '9');

-- ----------------------------
-- Table structure for userrelease
-- ----------------------------
DROP TABLE IF EXISTS `userrelease`;
CREATE TABLE `userrelease` (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `modified` datetime DEFAULT NULL,
                               `display` int(11) NOT NULL DEFAULT '1',
                               `uid` int(11) NOT NULL,
                               `sid` int(11) NOT NULL,
                               PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userrelease
-- ----------------------------
INSERT INTO `userrelease` VALUES ('1', null, '1', '7', '91');
INSERT INTO `userrelease` VALUES ('2', null, '1', '7', '92');
INSERT INTO `userrelease` VALUES ('3', null, '1', '61', '95');
INSERT INTO `userrelease` VALUES ('4', null, '1', '50', '96');
INSERT INTO `userrelease` VALUES ('5', null, '1', '18', '97');
INSERT INTO `userrelease` VALUES ('6', null, '1', '29', '98');
INSERT INTO `userrelease` VALUES ('7', null, '1', '38', '99');
INSERT INTO `userrelease` VALUES ('8', null, '1', '44', '100');
INSERT INTO `userrelease` VALUES ('9', null, '1', '14', '101');
INSERT INTO `userrelease` VALUES ('10', null, '1', '52', '102');
INSERT INTO `userrelease` VALUES ('11', null, '1', '37', '103');
INSERT INTO `userrelease` VALUES ('12', null, '1', '43', '104');
INSERT INTO `userrelease` VALUES ('13', null, '1', '52', '105');
INSERT INTO `userrelease` VALUES ('14', null, '1', '61', '106');
INSERT INTO `userrelease` VALUES ('15', null, '1', '31', '107');
INSERT INTO `userrelease` VALUES ('16', null, '1', '51', '108');
INSERT INTO `userrelease` VALUES ('17', null, '1', '63', '109');
INSERT INTO `userrelease` VALUES ('18', null, '1', '29', '110');
INSERT INTO `userrelease` VALUES ('19', null, '1', '37', '111');
INSERT INTO `userrelease` VALUES ('20', null, '1', '16', '112');
INSERT INTO `userrelease` VALUES ('21', null, '1', '38', '113');
INSERT INTO `userrelease` VALUES ('22', null, '1', '65', '114');
INSERT INTO `userrelease` VALUES ('23', null, '1', '15', '115');
INSERT INTO `userrelease` VALUES ('24', null, '1', '61', '116');
INSERT INTO `userrelease` VALUES ('25', null, '1', '54', '117');
INSERT INTO `userrelease` VALUES ('26', null, '1', '73', '118');
INSERT INTO `userrelease` VALUES ('27', null, '1', '74', '119');
INSERT INTO `userrelease` VALUES ('28', null, '1', '46', '120');
INSERT INTO `userrelease` VALUES ('29', null, '1', '98', '121');
INSERT INTO `userrelease` VALUES ('30', null, '1', '50', '122');
INSERT INTO `userrelease` VALUES ('31', null, '1', '92', '123');
INSERT INTO `userrelease` VALUES ('32', null, '1', '60', '124');
INSERT INTO `userrelease` VALUES ('33', null, '1', '21', '125');
INSERT INTO `userrelease` VALUES ('34', null, '1', '79', '126');
INSERT INTO `userrelease` VALUES ('35', null, '1', '71', '127');
INSERT INTO `userrelease` VALUES ('36', null, '1', '90', '128');
INSERT INTO `userrelease` VALUES ('37', null, '1', '64', '129');
INSERT INTO `userrelease` VALUES ('38', null, '1', '89', '130');
INSERT INTO `userrelease` VALUES ('39', null, '1', '55', '131');
INSERT INTO `userrelease` VALUES ('40', null, '1', '29', '132');
INSERT INTO `userrelease` VALUES ('41', null, '1', '34', '133');
INSERT INTO `userrelease` VALUES ('42', null, '1', '92', '134');
INSERT INTO `userrelease` VALUES ('43', null, '1', '32', '135');
INSERT INTO `userrelease` VALUES ('44', null, '1', '89', '136');
INSERT INTO `userrelease` VALUES ('45', null, '1', '65', '137');
INSERT INTO `userrelease` VALUES ('46', null, '1', '91', '138');
INSERT INTO `userrelease` VALUES ('47', null, '1', '40', '139');
INSERT INTO `userrelease` VALUES ('48', null, '1', '55', '140');
INSERT INTO `userrelease` VALUES ('49', null, '1', '6', '141');
INSERT INTO `userrelease` VALUES ('50', null, '1', '88', '142');
-- ----------------------------
-- Table structure for userstate
-- ----------------------------
DROP TABLE IF EXISTS `userstate`;
CREATE TABLE `userstate` (
                             `id` int(11) NOT NULL AUTO_INCREMENT,
                             `credit` int(11) NOT NULL DEFAULT '80',
                             `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
                             `modified` datetime DEFAULT NULL,
                             `uid` int(11) NOT NULL,
                             PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userstate
-- ----------------------------

-- ----------------------------
-- Table structure for userwant
-- ----------------------------
DROP TABLE IF EXISTS `userwant`;
CREATE TABLE `userwant` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `modified` datetime DEFAULT NULL,
                            `display` int(11) NOT NULL DEFAULT '1',
                            `name` varchar(50) NOT NULL,
                            `sort` int(100) NOT NULL,
                            `quantity` int(11) NOT NULL,
                            `price` decimal(10,2) NOT NULL,
                            `remark` varchar(255) DEFAULT NULL,
                            `uid` int(11) NOT NULL,
                            PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of userwant
-- ----------------------------
INSERT INTO `userwant` VALUES ('1', '2025-12-21 21:03:38', '1', '马年限定', '1', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7');
INSERT INTO `userwant` VALUES ('2', '2025-12-21 21:03:38', '1', '马年限定d', '2', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7');
INSERT INTO `userwant` VALUES ('3', '2025-12-21 21:03:38', '1', '马年限定c', '5', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '2');

-- ----------------------------
-- Table structure for requireproduct (求购商品表)
-- ----------------------------
DROP TABLE IF EXISTS `requireproduct`;
CREATE TABLE `requireproduct` (
                            `id` int(11) NOT NULL AUTO_INCREMENT,
                            `modified` datetime DEFAULT NULL,
                            `display` int(11) NOT NULL DEFAULT '1',
                            `name` varchar(50) NOT NULL,
                            `sort` int(100) NOT NULL,
                            `quantity` int(11) NOT NULL,
                            `price` decimal(10,2) NOT NULL,
                            `remark` varchar(255) DEFAULT NULL,
                            `uid` int(11) NOT NULL,
                            `requester_campus` VARCHAR(50) DEFAULT NULL COMMENT '求购者所在校区',
                            PRIMARY KEY (`id`),
                            KEY `idx_uid` (`uid`) USING BTREE,
                            KEY `idx_requester_campus` (`requester_campus`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of requireproduct
-- ----------------------------
INSERT INTO `requireproduct` VALUES ('1', '2025-12-21 21:03:38', '1', '马年限定', '1', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7', NULL);
INSERT INTO `requireproduct` VALUES ('2', '2025-12-21 21:03:38', '1', '马年限定d', '2', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7', NULL);
INSERT INTO `requireproduct` VALUES ('3', '2025-12-21 21:03:38', '1', '马年限定c', '5', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '2', NULL);
INSERT INTO `requireproduct` VALUES ('4', '2025-12-21 21:03:38', '1', '马年限定c', '79', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '3', NULL);
INSERT INTO `requireproduct` VALUES ('5', '2025-12-21 21:03:38', '1', '马年限定c', '1', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '1', NULL);
INSERT INTO `requireproduct` VALUES ('6', '2025-12-21 21:03:38', '1', '马年限定x', '50', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7', NULL);
INSERT INTO `requireproduct` VALUES ('7', '2025-12-21 21:03:38', '1', '马年限定c', '1', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7', NULL);
INSERT INTO `requireproduct` VALUES ('8', '2025-12-21 21:03:38', '1', '马年限定g', '44', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '4', NULL);
INSERT INTO `requireproduct` VALUES ('9', '2025-12-21 21:03:38', '1', '马年限定 d', '33', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7', NULL);
INSERT INTO `requireproduct` VALUES ('10', '2025-12-21 21:03:38', '1', '马年限定b', '78', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '5', NULL);
INSERT INTO `requireproduct` VALUES ('11', '2025-12-21 21:03:38', '1', '马年限定g', '36', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '6', NULL);
INSERT INTO `requireproduct` VALUES ('12', '2025-12-21 21:03:38', '1', '马年限定j', '66', '1', '1.00', '好东西哟，一般来说，好的东西都是需要很多很多人来抢着买的，一万年太久，只争朝夕', '7', NULL);

-- ----------------------------
-- Table structure for wantcontext
-- ----------------------------
DROP TABLE IF EXISTS `wantcontext`;
CREATE TABLE `wantcontext` (
                               `id` int(11) NOT NULL AUTO_INCREMENT,
                               `modified` datetime DEFAULT NULL,
                               `uwid` int(11) NOT NULL,
                               `context` varchar(255) NOT NULL,
                               `display` int(11) NOT NULL DEFAULT '1',
                               PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wantcontext
-- ----------------------------
-- ----------------------------
-- Table structure for goods_template
-- ----------------------------
DROP TABLE IF EXISTS `goods_template`;
CREATE TABLE `goods_template` (
                                  `template_id` int(11) NOT NULL AUTO_INCREMENT,
                                  `user_id` int(11) NOT NULL COMMENT '用户ID',
                                  `category_id` int(11) NOT NULL COMMENT '分类ID（对应shopinformation的sort字段）',
                                  `description` varchar(255) DEFAULT NULL COMMENT '商品描述',
                                  `freight` decimal(10,2) DEFAULT NULL COMMENT '运费',
                                  `modified` datetime DEFAULT NULL COMMENT '修改时间',
                                  PRIMARY KEY (`template_id`),
                                  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品发布模板表';

-- ========================================
-- 以下为数据库升级脚本（合并自 complete_upgrade.sql）
-- 包含所有表结构升级和数据迁移
-- 执行日期：2026-01-02
-- ========================================

-- ========================================
-- 第一部分：表结构升级
-- ========================================

-- 1. 为 userinformation 表添加位置相关字段
SET @dbname = DATABASE();
SET @tablename = 'userinformation';

-- 添加 campus 字段
SET @columnname = 'campus';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(50) DEFAULT NULL COMMENT ''校区''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 添加 building 字段
SET @columnname = 'building';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(50) DEFAULT NULL COMMENT ''楼栋''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 添加 room_number 字段
SET @columnname = 'room_number';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(20) DEFAULT NULL COMMENT ''房间号''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 添加 location_updated_at 字段
SET @columnname = 'location_updated_at';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' TIMESTAMP NULL DEFAULT NULL COMMENT ''位置信息更新时间''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 2. 为 shopinformation 表添加校区和交付方式字段
SET @tablename = 'shopinformation';

-- 添加 seller_campus 字段
SET @columnname = 'seller_campus';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(50) DEFAULT NULL COMMENT ''卖家所在校区''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 添加 prefer_delivery 字段
SET @columnname = 'prefer_delivery';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(20) DEFAULT ''自提'' COMMENT ''偏好交付方式：自提/送货上门/快递''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 3. 为 requireproduct 表添加校区字段
SET @dbname = DATABASE();
SET @tablename = 'requireproduct';
SET @columnname = 'requester_campus';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(50) DEFAULT NULL COMMENT ''求购者所在校区''')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 4. 创建订单表（如果不存在）
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_number` VARCHAR(50) NOT NULL COMMENT '订单编号',
  `buyer_id` INT NOT NULL COMMENT '买家ID',
  `seller_id` INT NOT NULL COMMENT '卖家ID',
  `product_id` INT NOT NULL COMMENT '商品ID',
  `product_name` VARCHAR(200) NOT NULL COMMENT '商品名称',
  `quantity` INT NOT NULL DEFAULT 1 COMMENT '购买数量',
  `unit_price` DECIMAL(10,2) NOT NULL COMMENT '单价',
  `total_price` DECIMAL(10,2) NOT NULL COMMENT '总价',
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending' COMMENT '订单状态：pending/confirmed/completed/cancelled',
  `delivery_method` VARCHAR(20) DEFAULT '自提' COMMENT '交付方式：自提/送货上门/快递',
  `delivery_address` VARCHAR(200) DEFAULT NULL COMMENT '送货地址',
  `buyer_campus` VARCHAR(50) DEFAULT NULL COMMENT '买家校区',
  `seller_campus` VARCHAR(50) DEFAULT NULL COMMENT '卖家校区',
  `notes` TEXT DEFAULT NULL COMMENT '订单备注',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_number` (`order_number`),
  KEY `idx_buyer_id` (`buyer_id`),
  KEY `idx_seller_id` (`seller_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ========================================
-- 第二部分：数据迁移
-- ========================================

-- 1. 为现有用户随机分配校区（示例数据）
-- 注意：这里使用随机分配，实际使用时应该根据真实情况修改
UPDATE `userinformation`
SET `campus` = CASE 
    WHEN MOD(id, 4) = 0 THEN '东校区'
    WHEN MOD(id, 4) = 1 THEN '西校区'
    WHEN MOD(id, 4) = 2 THEN '南校区'
    ELSE '北校区'
END
WHERE `campus` IS NULL OR `campus` = '';

-- 2. 为现有商品同步卖家校区信息
UPDATE `shopinformation` s
INNER JOIN `userinformation` u ON s.uid = u.id
SET s.seller_campus = u.campus
WHERE s.seller_campus IS NULL OR s.seller_campus = '';

-- 3. 为求购信息同步用户校区
UPDATE `requireproduct` r
INNER JOIN `userinformation` u ON r.uid = u.id
SET r.requester_campus = u.campus
WHERE r.requester_campus IS NULL OR r.requester_campus = '';

-- ========================================
-- 第三部分：创建视图和索引
-- ========================================

-- 1. 创建校区统计视图
CREATE OR REPLACE VIEW `campus_statistics` AS
SELECT 
    u.campus,
    COUNT(DISTINCT u.id) as user_count,
    COUNT(DISTINCT s.id) as shop_count,
    COUNT(DISTINCT r.id) as require_count
FROM `userinformation` u
LEFT JOIN `shopinformation` s ON u.id = s.uid
LEFT JOIN `requireproduct` r ON u.id = r.uid
WHERE u.campus IS NOT NULL
GROUP BY u.campus;

-- 2. 为校区字段添加索引（提高查询性能）
-- 为 userinformation 表添加索引
SET @dbname = DATABASE();
SET @tablename = 'userinformation';
SET @indexname = 'idx_campus';
SET @columnname = 'campus';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
   WHERE table_name = @tablename AND table_schema = @dbname AND index_name = @indexname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD INDEX ', @indexname, ' (', @columnname, ')')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 为 shopinformation 表添加索引
SET @tablename = 'shopinformation';
SET @indexname = 'idx_seller_campus';
SET @columnname = 'seller_campus';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
   WHERE table_name = @tablename AND table_schema = @dbname AND index_name = @indexname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD INDEX ', @indexname, ' (', @columnname, ')')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 为 requireproduct 表添加索引（使用动态SQL避免重复添加）
SET @dbname = DATABASE();
SET @tablename = 'requireproduct';
SET @indexname = 'idx_requester_campus';
SET @columnname = 'requester_campus';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (index_name = @indexname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD INDEX ', @indexname, ' (', @columnname, ')')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- ========================================
-- 升级完成！
-- ========================================
-- 说明：
-- 1. 本脚本已合并基础数据库结构和所有升级内容
-- 2. 可以安全地重复执行，不会导致数据丢失
-- 3. 新增功能：用户位置管理、校区筛选、订单管理
-- 4. 更新日期：2026-01-02
-- ========================================
-- 第四部分：验证升级结果
-- ========================================

SELECT '========================================' AS '';
SELECT '数据库升级完成！' AS '状态';
SELECT '========================================' AS '';

SELECT '用户校区分布' AS '统计类型';
SELECT campus, COUNT(*) as count 
FROM userinformation 
WHERE campus IS NOT NULL 
GROUP BY campus;

SELECT '商品校区分布' AS '统计类型';
SELECT seller_campus, COUNT(*) as count 
FROM shopinformation 
WHERE seller_campus IS NOT NULL 
GROUP BY seller_campus;

SELECT '求购信息校区分布' AS '统计类型';
SELECT requester_campus, COUNT(*) as count 
FROM requireproduct 
WHERE requester_campus IS NOT NULL 
GROUP BY requester_campus;

SELECT '========================================' AS '';
SELECT '所有升级和迁移操作已完成！' AS '完成状态';
SELECT '========================================' AS '';

