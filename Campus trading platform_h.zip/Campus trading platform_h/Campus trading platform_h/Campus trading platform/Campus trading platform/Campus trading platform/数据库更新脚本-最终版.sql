-- ============================================
-- 校园二手交易平台 - 新增功能数据库更新脚本（最终版）
-- 成员C负责模块：价格参考、求购匹配、消息提醒优化
-- ============================================

-- 1. 创建求购订阅表（buy_subscribe）
DROP TABLE IF EXISTS `buy_subscribe`;
CREATE TABLE `buy_subscribe` (
    `subscribe_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订阅ID',
    `user_id` int(11) NOT NULL COMMENT '用户ID',
    `category_id` int(11) NOT NULL COMMENT '分类ID（对应shopinformation的sort字段）',
    `modified` datetime DEFAULT NULL COMMENT '修改时间',
    `display` int(11) NOT NULL DEFAULT '1' COMMENT '是否有效：0=取消, 1=有效',
    PRIMARY KEY (`subscribe_id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_category_id` (`category_id`),
    UNIQUE KEY `uk_user_category` (`user_id`, `category_id`, `display`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='求购订阅表';

-- 2. 检查并创建 message 表（如果不存在）
SET @dbname = DATABASE();
SET @tablename = 'message';
SET @tableExists = (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
    WHERE table_schema = @dbname
      AND table_name = @tablename
);

-- 如果表不存在，创建完整的 message 表
SET @createTableSQL = IF(
    @tableExists = 0,
    CONCAT('CREATE TABLE `', @tablename, '` (
        `id` int(11) NOT NULL AUTO_INCREMENT COMMENT ''消息ID'',
        `from_user_id` int(11) NOT NULL COMMENT ''发送者用户ID'',
        `to_user_id` int(11) NOT NULL COMMENT ''接收者用户ID'',
        `content` varchar(500) NOT NULL COMMENT ''消息内容'',
        `message_type` int(11) NOT NULL DEFAULT ''1'' COMMENT ''消息类型：1=交易, 2=价格提醒, 3=过期提醒'',
        `bargain_type` varchar(50) DEFAULT NULL COMMENT ''议价类型（如：少5元、包邮等）'',
        `related_id` int(11) DEFAULT NULL COMMENT ''关联ID（商品ID或求购ID）'',
        `is_read` int(11) NOT NULL DEFAULT ''0'' COMMENT ''是否已读：0=未读, 1=已读'',
        `modified` datetime DEFAULT NULL COMMENT ''修改时间'',
        `display` int(11) NOT NULL DEFAULT ''1'' COMMENT ''是否显示：0=删除, 1=正常'',
        PRIMARY KEY (`id`),
        KEY `idx_to_user_id` (`to_user_id`),
        KEY `idx_message_type` (`message_type`),
        KEY `idx_is_read` (`is_read`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT=''消息表'';'),
    'SELECT 1'
);

PREPARE stmt FROM @createTableSQL;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 3. 如果表已存在，检查并添加新字段（如果字段不存在）

-- 检查并添加 message_type 字段
SET @columnname = 'message_type';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' int(11) NOT NULL DEFAULT ''1'' COMMENT ''消息类型：1=交易, 2=价格提醒, 3=过期提醒'' AFTER content')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 检查并添加 bargain_type 字段
SET @columnname = 'bargain_type';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' varchar(50) DEFAULT NULL COMMENT ''议价类型（如：少5元、包邮等）'' AFTER message_type')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 检查并添加 related_id 字段
SET @columnname = 'related_id';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' int(11) DEFAULT NULL COMMENT ''关联ID（商品ID或求购ID）'' AFTER bargain_type')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- 检查并添加 is_read 字段
SET @columnname = 'is_read';
SET @preparedStatement = (SELECT IF(
  (
    SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE
      (table_name = @tablename)
      AND (table_schema = @dbname)
      AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' int(11) NOT NULL DEFAULT ''0'' COMMENT ''是否已读：0=未读, 1=已读'' AFTER related_id')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- ============================================
-- 验证脚本（可选）
-- ============================================
-- SELECT 'buy_subscribe表' as '表名', COUNT(*) as '记录数' FROM buy_subscribe;
-- SELECT COLUMN_NAME, COLUMN_TYPE, COLUMN_COMMENT 
-- FROM INFORMATION_SCHEMA.COLUMNS 
-- WHERE TABLE_SCHEMA = DATABASE() 
--   AND TABLE_NAME = 'message' 
--   AND COLUMN_NAME IN ('message_type', 'bargain_type', 'related_id', 'is_read')
-- ORDER BY ORDINAL_POSITION;

