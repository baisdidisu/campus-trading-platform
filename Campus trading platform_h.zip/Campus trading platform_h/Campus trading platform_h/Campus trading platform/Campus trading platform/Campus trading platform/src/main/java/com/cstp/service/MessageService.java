package com.cstp.service;

import com.cstp.pojo.Message;

import java.util.List;

public interface MessageService {
    /**
     * 发送消息
     * @param message 消息对象
     * @return 插入结果
     */
    int sendMessage(Message message);

    /**
     * 查询用户消息列表
     * @param toUserId 接收者用户ID
     * @param messageType 消息类型（可选）
     * @param page 页码
     * @param pageSize 每页大小
     * @return 消息列表
     */
    List<Message> getMessageList(Integer toUserId, Integer messageType, Integer page, Integer pageSize);

    /**
     * 统计未读消息数量
     * @param toUserId 接收者用户ID
     * @param messageType 消息类型（可选）
     * @return 未读消息数量
     */
    int countUnreadMessages(Integer toUserId, Integer messageType);

    /**
     * 标记消息为已读
     * @param messageId 消息ID
     * @return 更新结果
     */
    int markAsRead(Integer messageId);
}

