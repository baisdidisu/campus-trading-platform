package com.cstp.pojo;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单操作日志实体类
 */
public class OrderOperationLog implements Serializable {
    private Integer id;

    private Integer orderId;

    private Integer operatorId;

    private String operationType;

    private String operationDesc;

    private Date createdTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getOperatorId() {
        return operatorId;
    }

    public void setOperatorId(Integer operatorId) {
        this.operatorId = operatorId;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType == null ? null : operationType.trim();
    }

    public String getOperationDesc() {
        return operationDesc;
    }

    public void setOperationDesc(String operationDesc) {
        this.operationDesc = operationDesc == null ? null : operationDesc.trim();
    }

    public Date getCreatedTime() {
        return createdTime == null ? null : (Date) createdTime.clone();
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime == null ? null : (Date) createdTime.clone();
    }
}

