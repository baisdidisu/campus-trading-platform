package com.cstp.dao;

import com.cstp.pojo.OrderOperationLog;

import java.util.List;

public interface OrderOperationLogMapper {
    int insert(OrderOperationLog record);

    int insertSelective(OrderOperationLog record);

    OrderOperationLog selectByPrimaryKey(Integer id);

    List<OrderOperationLog> selectByOrderId(Integer orderId);
}

