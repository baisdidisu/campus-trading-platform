package com.cstp.controller;

import com.cstp.pojo.UserInformation;
import com.cstp.pojo.UserPassword;
import com.cstp.response.BaseResponse;
import com.cstp.service.UserInformationService;
import com.cstp.service.UserPasswordService;
import com.cstp.tool.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 找回密码&验证码校验控制器
 * 已修复：log报错、token未销毁、注解混用、重复校验、异常处理等问题
 */
@RestController
@Slf4j // ✅ 核心：添加该注解，自动生成log对象，解决符号解析失败
public class ForgetController {

    @Resource
    private UserPasswordService userPasswordService;
    @Resource
    private UserInformationService userInformationService;

    /**
     * 校验手机验证码（注册/找回密码通用）
     */
    @RequestMapping(value = "checkCode.do", method = {RequestMethod.POST, RequestMethod.GET})
    public Map<String, Object> checkPhone(HttpServletRequest request,
                                           @RequestParam String code, @RequestParam String token) {
        Map<String, Object> map = new HashMap<>();
        String name = request.getParameter("name");

        // 存储用户名到session（注册场景）
        if (!StringUtils.getInstance().isNullOrEmpty(name)) {
            request.getSession().setAttribute("name", name);
        }

        // 1. Token防重复提交校验 + 校验后立即销毁token（核心：防止重复提交）
        String checkCodeToken = (String) request.getSession().getAttribute("token");
        if (StringUtils.getInstance().isNullOrEmpty(checkCodeToken) || !checkCodeToken.equals(token)) {
            log.warn("⚠️ 验证码校验失败：token验证失败，非法重复提交");
            map.put("result", 0);
            return map;
        }
        request.getSession().removeAttribute("token"); // ✅ 核心：验证码校验通过后销毁token，防止重复使用

        // 2. 验证码有效性校验
        if (!checkCodePhone(code, request)) {
            log.warn("⚠️ 验证码校验失败：用户输入验证码错误");
            map.put("result", 0);
            return map;
        }

        // ✅ 修复：验证码校验成功后，生成新的token供后续insertUser.do使用
        String newToken = com.cstp.token.TokenProccessor.getInstance().makeToken();
        request.getSession().setAttribute("token", newToken);

        log.info("✅ 验证码校验成功，已生成新token供后续使用");
        map.put("result", 1);
        map.put("token", newToken); // ✅ 返回新token给前端更新
        return map;
    }

    /**
     * 更新密码（找回密码专属）
     */
    @RequestMapping("updatePassword.do")
    public BaseResponse updatePassword(HttpServletRequest request,
                                       @RequestParam String password,
                                       @RequestParam String token) {
        // ✅ 修复1：移除冗余的Model、code参数（Model和@RestController冲突，code已在checkCode.do校验）
        // 1. Token防重复提交校验 + 校验后立即销毁token（核心修复：防止重复提交漏洞）
        String updatePasswordToken = (String) request.getSession().getAttribute("token");
        if (StringUtils.getInstance().isNullOrEmpty(updatePasswordToken) || !updatePasswordToken.equals(token)) {
            log.warn("⚠️ 找回密码失败：token验证失败，请勿重复提交");
            return BaseResponse.fail("请勿重复提交");
        }
        request.getSession().removeAttribute("token"); // ✅ 核心：验证后销毁token，彻底杜绝重复提交

        // 2. 从session获取手机号（sendCode.do中已存储）
        String realPhone = (String) request.getSession().getAttribute("phone");
        if (StringUtils.getInstance().isNullOrEmpty(realPhone)) {
            log.warn("⚠️ 找回密码失败：session中未获取到手机号");
            return BaseResponse.fail("操作超时，请重新获取验证码");
        }

        // 3. 密码加密 + 组装更新对象
        String newPassword = StringUtils.getInstance().getMD5(password);
        UserPassword userPassword = new UserPassword();
        int uid;
        try {
            uid = userInformationService.selectIdByPhone(realPhone);
            if (uid == 0) {
                log.warn("⚠️ 找回密码失败：手机号{}未注册", realPhone);
                return BaseResponse.fail("该手机号未注册");
            }
        } catch (Exception e) {
            log.error("❌ 找回密码失败：查询用户ID异常", e); // ✅ 修复：替换e.printStackTrace()为日志打印
            return BaseResponse.fail("操作失败，请稍后重试");
        }

        // 4. 更新密码逻辑
        try {
            int id = userPasswordService.selectByUid(uid).getId();
            userPassword.setId(id);
            userPassword.setUid(uid);
            userPassword.setModified(new Date());
            userPassword.setPassword(newPassword);

            int result = userPasswordService.updateByPrimaryKeySelective(userPassword);
            if (result != 1) {
                log.warn("⚠️ 找回密码失败：数据库更新密码受影响行数为0");
                return BaseResponse.fail("密码修改失败");
            }
        } catch (Exception e) {
            log.error("❌ 找回密码失败：更新密码数据库异常", e);
            return BaseResponse.fail("操作失败，请稍后重试");
        }

        // 5. 密码更新成功，存储用户信息到session
        UserInformation userInformation = userInformationService.selectByPrimaryKey(uid);
        request.getSession().setAttribute("userInformation", userInformation);
        // ✅ 清理session中无用数据，释放资源
        request.getSession().removeAttribute("codePhone");
        request.getSession().removeAttribute("phone");

        log.info("✅ 手机号{}密码修改成功", realPhone);
        return BaseResponse.success("密码修改成功，即将跳转首页");
    }

    /**
     * 校验手机验证码（不区分大小写）
     */
    private boolean checkCodePhone(String codePhone, HttpServletRequest request) {
        String trueCodePhone = (String) request.getSession().getAttribute("codePhone");
        // 验证码非空校验 + 不区分大小写匹配
        return !StringUtils.getInstance().isNullOrEmpty(trueCodePhone)
                && trueCodePhone.equals(codePhone.toLowerCase());
    }
}//已修改
