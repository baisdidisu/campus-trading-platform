package com.cstp;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EntityScan(basePackages = "com.cstp.*")
@ComponentScan({"com.cstp.*"})
@MapperScan({"com.cstp.dao"}) //扫描mybatis，需注解 @Repository
@EnableAsync
@EnableScheduling // 启用定时任务
public class UsedTradingPlatformApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder(UsedTradingPlatformApplication.class).run(args);
    }

}
