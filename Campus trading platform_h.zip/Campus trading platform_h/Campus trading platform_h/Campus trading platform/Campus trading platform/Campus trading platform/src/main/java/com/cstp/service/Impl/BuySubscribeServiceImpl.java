package com.cstp.service.Impl;

import com.cstp.dao.BuySubscribeMapper;
import com.cstp.pojo.BuySubscribe;
import com.cstp.service.BuySubscribeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class BuySubscribeServiceImpl implements BuySubscribeService {

    @Resource
    private BuySubscribeMapper buySubscribeMapper;

    @Override
    public boolean subscribeCategory(Integer userId, Integer categoryId) {
        try {
            // 检查是否已经订阅（包含已取消的记录）
            BuySubscribe existing = buySubscribeMapper.selectAnyByUserIdAndCategoryId(userId, categoryId);
            if (existing != null) {
                // 如果已存在但被取消，则重新激活
                if (existing.getDisplay() != null && existing.getDisplay() == 0) {
                    existing.setDisplay(1);
                    existing.setModified(new Date());
                    // 只更新 display/modified，避免触发 (user_id,category_id) 唯一索引的重复写入
                    return buySubscribeMapper.updateDisplayByPrimaryKey(existing) > 0;
                }
                // 如果已存在且有效，提示已订阅
                return false;
            }
            
            // 创建新订阅
            BuySubscribe subscribe = new BuySubscribe();
            subscribe.setUserId(userId);
            subscribe.setCategoryId(categoryId);
            subscribe.setModified(new Date());
            subscribe.setDisplay(1);
            
            return buySubscribeMapper.insertSelective(subscribe) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean unsubscribeCategory(Integer userId, Integer categoryId) {
        try {
            BuySubscribe subscribe = buySubscribeMapper.selectByUserIdAndCategoryId(userId, categoryId);
            if (subscribe == null) {
                return false;
            }
            
            // 软删除：设置display为0
            subscribe.setDisplay(0);
            subscribe.setModified(new Date());
            // 只更新 display/modified，避免唯一索引冲突
            return buySubscribeMapper.updateDisplayByPrimaryKey(subscribe) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Integer> getUserIdsByCategoryId(Integer categoryId) {
        try {
            return buySubscribeMapper.selectUserIdsByCategoryId(categoryId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Integer> getCategoryIdsByUserId(Integer userId) {
        try {
            return buySubscribeMapper.selectCategoryIdsByUserId(userId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

