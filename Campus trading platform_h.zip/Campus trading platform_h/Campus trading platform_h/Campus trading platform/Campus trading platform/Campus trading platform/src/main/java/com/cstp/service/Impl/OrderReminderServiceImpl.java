package com.cstp.service.Impl;

import com.cstp.dao.OrderFormMapper;
import com.cstp.dao.OrderReminderMapper;
import com.cstp.pojo.OrderForm;
import com.cstp.pojo.OrderReminder;
import com.cstp.service.OrderReminderService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class OrderReminderServiceImpl implements OrderReminderService {

    @Resource
    private OrderReminderMapper orderReminderMapper;

    @Resource
    private OrderFormMapper orderFormMapper;

    @Override
    public int insert(OrderReminder record) {
        return orderReminderMapper.insert(record);
    }

    @Override
    public int insertSelective(OrderReminder record) {
        return orderReminderMapper.insertSelective(record);
    }

    @Override
    public OrderReminder selectByPrimaryKey(Integer id) {
        return orderReminderMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<OrderReminder> selectPendingReminders() {
        return orderReminderMapper.selectPendingReminders();
    }

    @Override
    public int updateByPrimaryKeySelective(OrderReminder record) {
        return orderReminderMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int markAsSent(Integer id) {
        return orderReminderMapper.markAsSent(id);
    }

    @Override
    public void createRemindersForOrder(Integer orderId, Integer userId) {
        OrderForm order = orderFormMapper.selectByPrimaryKey(orderId);
        if (order == null || order.getExpireTime() == null) {
            return;
        }

        // 创建过期前24小时提醒
        Calendar cal = Calendar.getInstance();
        cal.setTime(order.getExpireTime());
        cal.add(Calendar.HOUR, -24);
        
        OrderReminder reminder24h = new OrderReminder();
        reminder24h.setOrderId(orderId);
        reminder24h.setUserId(userId);
        reminder24h.setReminderType("expire");
        reminder24h.setReminderTime(cal.getTime());
        reminder24h.setIsSent(false);
        reminder24h.setCreatedTime(new Date());
        orderReminderMapper.insertSelective(reminder24h);

        // 创建过期前1小时提醒
        cal.setTime(order.getExpireTime());
        cal.add(Calendar.HOUR, -1);
        
        OrderReminder reminder1h = new OrderReminder();
        reminder1h.setOrderId(orderId);
        reminder1h.setUserId(userId);
        reminder1h.setReminderType("expire");
        reminder1h.setReminderTime(cal.getTime());
        reminder1h.setIsSent(false);
        reminder1h.setCreatedTime(new Date());
        orderReminderMapper.insertSelective(reminder1h);
    }
}

