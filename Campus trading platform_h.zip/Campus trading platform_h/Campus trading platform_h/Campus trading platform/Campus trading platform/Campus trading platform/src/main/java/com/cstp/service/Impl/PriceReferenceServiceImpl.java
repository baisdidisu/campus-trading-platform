package com.cstp.service.Impl;

import com.cstp.dao.ShopInformationMapper;
import com.cstp.pojo.Message;
import com.cstp.service.MessageService;
import com.cstp.service.PriceReferenceService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class PriceReferenceServiceImpl implements PriceReferenceService {

    @Resource
    private ShopInformationMapper shopInformationMapper;

    @Resource
    private MessageService messageService;

    @Override
    public Map<String, Object> getPriceStatisticsBySort(Integer sort) {
        // 查询同类商品的成交价格统计
        Map<String, Object> statistics = shopInformationMapper.selectPriceStatisticsBySort(sort);
        
        // 如果查询结果为空，返回默认值
        if (statistics == null || statistics.isEmpty()) {
            Map<String, Object> defaultResult = new HashMap<>();
            defaultResult.put("minPrice", 0);
            defaultResult.put("maxPrice", 0);
            defaultResult.put("avgPrice", 0);
            return defaultResult;
        }
        
        // 处理BigDecimal类型，转换为Double便于前端使用
        Map<String, Object> result = new HashMap<>();
        Object minPrice = statistics.get("minPrice");
        Object maxPrice = statistics.get("maxPrice");
        Object avgPrice = statistics.get("avgPrice");
        
        result.put("minPrice", minPrice instanceof BigDecimal ? 
            ((BigDecimal) minPrice).doubleValue() : (minPrice != null ? minPrice : 0));
        result.put("maxPrice", maxPrice instanceof BigDecimal ? 
            ((BigDecimal) maxPrice).doubleValue() : (maxPrice != null ? maxPrice : 0));
        result.put("avgPrice", avgPrice instanceof BigDecimal ? 
            ((BigDecimal) avgPrice).doubleValue() : (avgPrice != null ? avgPrice : 0));
        
        return result;
    }

    @Override
    public boolean sendBargainMessage(Integer buyerId, Integer sellerId, Integer shopId, String bargainType) {
        try {
            // 构建消息内容
            String content = String.format("买家向您发送了议价请求：%s，商品ID：%d", bargainType, shopId);
            
            // 创建消息对象
            Message message = new Message();
            message.setFromUserId(buyerId);
            message.setToUserId(sellerId);
            message.setContent(content);
            message.setMessageType(1); // 交易消息
            message.setBargainType(bargainType);
            message.setRelatedId(shopId);
            message.setModified(new Date());
            message.setIsRead(0);
            message.setDisplay(1);
            
            // 发送消息
            int result = messageService.sendMessage(message);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
