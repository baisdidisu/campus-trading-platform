/**
 * 统一的位置管理工具
 * 用于处理所有与位置相关的操作
 */
var LocationManager = (function() {
    'use strict';
    
    // API 端点
    var API = {
        GET: '/location/get',
        UPDATE: '/location/update'
    };
    
    /**
     * 获取用户位置信息
     * @param {Function} successCallback - 成功回调函数
     * @param {Function} errorCallback - 失败回调函数
     */
    function get(successCallback, errorCallback) {
        $.ajax({
            url: API.GET,
            type: 'GET',
            success: function(response) {
                if (response.result === 1 && response.data) {
                    if (successCallback) {
                        successCallback(response.data);
                    }
                } else if (response.code === 200 && response.data) {
                    if (successCallback) {
                        successCallback(response.data);
                    }
                } else {
                    if (errorCallback) {
                        errorCallback(response.msg || '获取位置信息失败');
                    }
                }
            },
            error: function(xhr, status, error) {
                if (errorCallback) {
                    errorCallback('网络错误：' + error);
                }
            }
        });
    }
    
    /**
     * 更新用户位置信息
     * @param {Object} locationData - 位置数据 {campus, building, room}
     * @param {Function} successCallback - 成功回调函数
     * @param {Function} errorCallback - 失败回调函数
     */
    function update(locationData, successCallback, errorCallback) {
        // 验证必填项
        if (!locationData.campus) {
            if (errorCallback) {
                errorCallback('请选择校区');
            }
            return;
        }
        
        if (!locationData.building) {
            if (errorCallback) {
                errorCallback('请填写楼栋号');
            }
            return;
        }
        
        $.ajax({
            url: API.UPDATE,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(locationData),
            success: function(response) {
                if (response.result === 1) {
                    if (successCallback) {
                        successCallback(response.data);
                    }
                } else if (response.code === 200) {
                    if (successCallback) {
                        successCallback(response.data);
                    }
                } else {
                    if (errorCallback) {
                        errorCallback(response.msg || '更新失败');
                    }
                }
            },
            error: function(xhr, status, error) {
                if (errorCallback) {
                    errorCallback('网络错误：' + error);
                }
            }
        });
    }
    
    /**
     * 格式化位置信息为字符串
     * @param {Object} location - 位置对象
     * @returns {String} 格式化后的位置字符串
     */
    function format(location) {
        if (!location) {
            return '未设置';
        }
        
        var parts = [];
        if (location.campus) {
            parts.push(location.campus);
        }
        if (location.building) {
            parts.push(location.building);
        }
        if (location.room || location.roomNumber) {
            parts.push(location.room || location.roomNumber);
        }
        
        return parts.length > 0 ? parts.join(' ') : '未设置';
    }
    
    /**
     * 从表单获取位置数据
     * @param {String} campusSelector - 校区选择器
     * @param {String} buildingSelector - 楼栋选择器
     * @param {String} roomSelector - 房间选择器
     * @returns {Object} 位置数据对象
     */
    function getFromForm(campusSelector, buildingSelector, roomSelector) {
        return {
            campus: $(campusSelector).val(),
            building: $(buildingSelector).val(),
            room: $(roomSelector).val()
        };
    }
    
    /**
     * 填充表单
     * @param {String} campusSelector - 校区选择器
     * @param {String} buildingSelector - 楼栋选择器
     * @param {String} roomSelector - 房间选择器
     */
    function fillForm(campusSelector, buildingSelector, roomSelector) {
        get(function(location) {
            if (location.campus) {
                $(campusSelector).val(location.campus);
            }
            if (location.building) {
                $(buildingSelector).val(location.building);
            }
            if (location.room || location.roomNumber) {
                $(roomSelector).val(location.room || location.roomNumber);
            }
        });
    }
    
    // 公开的 API
    return {
        get: get,
        update: update,
        format: format,
        getFromForm: getFromForm,
        fillForm: fillForm
    };
})();

