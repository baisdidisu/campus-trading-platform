// 求购订阅功能
// 参考w项目实现，兼容jQuery 1.3.2
$(function() {
    var isExpanded = false;
    
    // 加载订阅列表
    function loadBuySubscribeList() {
        $.ajax({
            url: '/getBuySubscriptions.do',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                // 兼容两种响应格式：response.result === 1 或 response.code === 200
                var isSuccess = (response.result === 1) || (response.code === 200);
                var categoryIds = response.data || [];
                
                var $list = $('#buy_subscribe_list');
                $list.empty();
                
                if (!isSuccess || categoryIds.length === 0) {
                    $list.append('<li style="padding:5px;color:#999;font-size:0.9em;">暂无订阅</li>');
                    return;
                }
                
                // 使用全局分类名称映射（从sub_category_names.js加载）
                // 如果没有加载，则使用默认映射作为后备
                var categoryNames = window.SUB_CATEGORY_NAMES || {
                    // 默认映射（仅作为后备，正常情况下应该从sub_category_names.js加载）
                    1: '苹果', 2: '三星', 3: '小米', 4: '华为', 5: '中兴',
                    6: '联想', 7: '魅族', 8: '其他', 9: '耳机',
                    10: '普通相机', 11: '单反', 12: '其他',
                    13: '笔记本', 14: '平板电脑', 15: '台式电脑', 16: '显示器',
                    17: '鼠标', 18: '硬盘', 19: 'U盘', 20: '移动硬盘', 21: '其他',
                    22: '洗衣机', 23: '饮水机', 24: '吹风机', 25: '剃须刀',
                    26: '风扇', 27: '煮蛋器', 28: '电磁炉', 29: '电饭煲', 30: '其他',
                    31: '耳机', 32: '音响', 33: '功放', 34: '低音炮', 35: '麦克风',
                    36: '上衣', 37: '裤子', 38: '裙子', 39: '其他',
                    40: '上衣', 41: '裤子', 42: '其他',
                    43: '运动鞋', 44: '皮鞋', 45: '帆布鞋', 46: '球鞋', 47: '板鞋', 48: '其他',
                    49: '运动鞋', 50: '皮鞋', 51: '帆布鞋', 52: '球鞋', 53: '板鞋', 54: '其他',
                    55: '背包', 56: '旅行箱', 57: '其他',
                    58: '机械表', 59: '石英表', 60: '电子表', 61: '其他',
                    62: '足球', 63: '羽毛球拍', 64: '网球拍', 65: '篮球',
                    66: '轮滑', 67: '乒乓球拍', 68: '滑板', 69: '其他',
                    70: '自行车', 71: '电动车', 72: '其他',
                    73: '文学', 74: '漫画', 75: '小说', 76: '其他',
                    77: '生物', 78: '化学', 79: '物理', 80: '语文', 81: '外语',
                    82: '数学', 83: '政治', 84: '历史', 85: '地理', 86: '计算机',
                    87: '机械', 88: '土木', 89: '艺术', 90: '其他',
                    91: '笔', 92: '其他',
                    94: '其他'
                };
                
                // 兼容jQuery 1.3.2，使用传统for循环而不是forEach
                for (var i = 0; i < categoryIds.length; i++) {
                    var categoryId = categoryIds[i];
                    var categoryName = categoryNames[categoryId] || '分类' + categoryId;
                    var $li = $('<li style="padding:5px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;"></li>');
                    $li.append('<span style="font-size:0.9em;">' + categoryName + '</span>');
                    var $unsubBtn = $('<button style="padding:2px 8px;background-color:#dc3545;color:white;border:none;border-radius:3px;cursor:pointer;font-size:0.8em;">取消</button>');
                    $unsubBtn.data('category-id', categoryId);
                    $li.append($unsubBtn);
                    $list.append($li);
                }
                
                // 绑定取消订阅按钮事件
                $list.find('button').click(function(e) {
                    e.stopPropagation();
                    var categoryId = $(this).data('category-id');
                    unsubscribeCategory(categoryId);
                });
            },
            error: function() {
                $('#buy_subscribe_list').html('<li style="padding:5px;color:#999;font-size:0.9em;">加载失败</li>');
            }
        });
    }
    
    // 取消订阅
    function unsubscribeCategory(categoryId) {
        if (!confirm('确定要取消订阅该分类吗？')) {
            return;
        }
        
        $.ajax({
            url: '/unsubscribeCategory.do',
            type: 'POST',
            data: {categoryId: categoryId},
            dataType: 'json',
            success: function(response) {
                // 兼容两种响应格式
                var isSuccess = (response.result === 1) || (response.code === 200);
                if (isSuccess) {
                    alert('取消订阅成功');
                    loadBuySubscribeList(); // 刷新列表
                    // 已修改：移除自动刷新页面，避免白屏，改为仅刷新订阅列表
                    // 如果需要更新订阅按钮状态，可以通过AJAX重新加载相关数据
                    // setTimeout(function() {
                    //     location.reload();
                    // }, 500);
                } else {
                    alert(response.msg || '取消订阅失败');
                }
            },
            error: function() {
                alert('网络错误，请重试');
            }
        });
    }
    
    // 展开/收起订阅列表
    // 兼容jQuery 1.3.2，使用on方法（jQuery 1.3.2支持）
    $('#toggle_buy_subscribe').on('click', function() {
        var $list = $('#buy_subscribe_list');
        var $toggle = $(this);
        if (isExpanded) {
            $list.slideUp(300);
            $toggle.text('我的订阅 (点击展开)');
            isExpanded = false;
        } else {
            $list.slideDown(300);
            $toggle.text('我的订阅 (点击收起)');
            isExpanded = true;
            // 展开时加载订阅列表（如果列表为空或只有一个"暂无订阅"项）
            var hasContent = $list.find('li').length > 0 && !$list.find('li').first().text().includes('暂无订阅') && !$list.find('li').first().text().includes('加载失败');
            if (!hasContent) {
                loadBuySubscribeList();
            }
        }
    });
    
    // 页面加载时，如果列表是展开的，则加载数据
    if ($('#buy_subscribe_list').is(':visible')) {
        loadBuySubscribeList();
    }
    
    // 暴露刷新函数供外部调用
    window.refreshBuySubscribeList = function() {
        loadBuySubscribeList();
    };
});
