package com.cstp.pojo;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单提醒实体类
 */
public class OrderReminder implements Serializable {
    private Integer id;

    private Integer orderId;

    private Integer userId;

    private String reminderType;

    private Date reminderTime;

    private Boolean isSent;

    private Date sentTime;

    private Date createdTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getReminderType() {
        return reminderType;
    }

    public void setReminderType(String reminderType) {
        this.reminderType = reminderType == null ? null : reminderType.trim();
    }

    public Date getReminderTime() {
        return reminderTime == null ? null : (Date) reminderTime.clone();
    }

    public void setReminderTime(Date reminderTime) {
        this.reminderTime = reminderTime == null ? null : (Date) reminderTime.clone();
    }

    public Boolean getIsSent() {
        return isSent;
    }

    public void setIsSent(Boolean isSent) {
        this.isSent = isSent;
    }

    public Date getSentTime() {
        return sentTime == null ? null : (Date) sentTime.clone();
    }

    public void setSentTime(Date sentTime) {
        this.sentTime = sentTime == null ? null : (Date) sentTime.clone();
    }

    public Date getCreatedTime() {
        return createdTime == null ? null : (Date) createdTime.clone();
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime == null ? null : (Date) createdTime.clone();
    }
}

