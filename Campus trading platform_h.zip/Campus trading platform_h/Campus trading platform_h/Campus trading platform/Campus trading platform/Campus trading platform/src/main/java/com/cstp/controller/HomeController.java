package com.cstp.controller;

import com.cstp.bean.ShopInformationBean;
import com.cstp.pojo.*;
import com.cstp.service.*;
import com.cstp.tool.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class HomeController {
    @Resource
    private ShopInformationService shopInformationService;
    @Resource
    private SpecificeService specificeService;
    @Resource
    private ClassificationService classificationService;
    @Resource
    private AllKindsService allKindsService;
    @Resource
    private ShopContextService shopContextService;


    @RequestMapping(value = {"/", "/home.do"})
    public String home(HttpServletRequest request, Model model) {
        UserInformation userInformation = (UserInformation) request.getSession().getAttribute("userInformation");
        // if user login,the session will have the "userInformation"
        if (!StringUtils.getInstance().isNullOrEmpty(userInformation)) {
            model.addAttribute("userInformation", userInformation);
        } else {
            userInformation = new UserInformation();
            model.addAttribute("userInformation", userInformation);
        }
        //一般形式进入首页
        try {
            List<ShopInformation> shopInformations = selectTen(1, 5);
            List<ShopInformationBean> list = new ArrayList<>();
            int counts = getShopCounts();
            model.addAttribute("shopInformationCounts", counts);

            // ✅ 修复：添加空值检查
            if (shopInformations != null && !shopInformations.isEmpty()) {
                String stringBuffer;
                for (ShopInformation shopInformation : shopInformations) {
                    try {
                        // ✅ 修复：安全获取分类名称
                        stringBuffer = getSortNameSafely(shopInformation.getSort());
                        ShopInformationBean shopInformationBean = new ShopInformationBean();
                        shopInformationBean.setId(shopInformation.getId());
                        shopInformationBean.setName(shopInformation.getName());
                        shopInformationBean.setLevel(shopInformation.getLevel());
                        shopInformationBean.setPrice(shopInformation.getPrice().doubleValue());
                        shopInformationBean.setRemark(shopInformation.getRemark());
                        shopInformationBean.setSort(stringBuffer);
                        shopInformationBean.setQuantity(shopInformation.getQuantity());
                        shopInformationBean.setUid(shopInformation.getUid());
                        shopInformationBean.setTransaction(shopInformation.getTransaction());
                        shopInformationBean.setImage(shopInformation.getImage());
                        list.add(shopInformationBean);
                    } catch (Exception e) {
                        // ✅ 单个商品处理失败不影响其他商品
                        System.err.println("处理首页商品失败，ID: " + shopInformation.getId() + ", 错误: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }

            model.addAttribute("shopInformationBean", list);
            System.out.println("✅ 首页加载成功，共 " + list.size() + " 件精选商品");
        } catch (Exception e) {
            // ✅ 修复：即使查询商品失败，也应该显示首页，而不是返回登录页
            e.printStackTrace();
            System.err.println("❌ 首页加载商品数据失败: " + e.getMessage());
            model.addAttribute("shopInformationBean", new ArrayList<>());
            model.addAttribute("shopInformationCounts", 0);
        }
        return "index";
    }

    //进入商城 - 已修改：支持多条件筛选参数（分类、校区、成色）
    @RequestMapping(value = "/mall_page.do")
    public String mallPage(HttpServletRequest request, Model model,
                           @RequestParam(required = false) Integer sort,
                           @RequestParam(required = false) String campus,
                           @RequestParam(required = false) Integer level) {
        UserInformation userInformation = (UserInformation) request.getSession().getAttribute("userInformation");
        if (StringUtils.getInstance().isNullOrEmpty(userInformation)) {
            userInformation = new UserInformation();
            model.addAttribute("userInformation", userInformation);
        } else {
            model.addAttribute("userInformation", userInformation);
        }
        
        // 已修改：如果有筛选条件，使用筛选查询；否则使用默认查询
        try {
            List<ShopInformation> shopInformations;
            int counts;
            
            // 已修改：如果有筛选条件，使用筛选查询；否则使用默认查询
            boolean hasFilter = (sort != null && sort != 0) || (campus != null && !campus.isEmpty()) 
                || (level != null && level != 0);
            
            if (hasFilter) {
                // 已修改：使用多条件筛选，支持第一层分类（allkinds）进行粗分类筛选
                Map<String, Object> params = new HashMap<String, Object>();
                if (sort != null && sort != 0) {
                    // 已修改：根据第一层分类ID，获取该大类下的所有第三层分类ID列表
                    List<Integer> specificIdsInCategory = getSpecificIdsByAllKindsId(sort);
                    if (specificIdsInCategory != null && !specificIdsInCategory.isEmpty()) {
                        params.put("sortList", specificIdsInCategory);
                    } else {
                        // 已修改：如果该大类下没有分类，返回空列表
                        shopInformations = new ArrayList<>();
                        counts = 0;
                        model.addAttribute("shopInformationBean", new ArrayList<>());
                        model.addAttribute("shopInformationCounts", 0);
                        model.addAttribute("selectedSort", sort);
                        model.addAttribute("selectedCampus", campus);
                        model.addAttribute("selectedLevel", level);
                        return "page/mall_page";
                    }
                }
                if (campus != null && !campus.isEmpty()) {
                    params.put("campus", campus);
                }
                if (level != null && level != 0) {
                    // 已修改：将前端筛选页面的成色值（1-5）映射到数据库中的成色值（3-10）
                    // 前端：1=全新, 2=九成新, 3=八成新, 4=七成新, 5=六成新以下
                    // 数据库：10=全新, 9=九成, 8=八成, 7=七成, 6=六成, 5=五成, 4=四成, 3=三成
                    Integer dbLevel = null;
                    switch (level) {
                        case 1: // 全新
                            dbLevel = 10;
                            break;
                        case 2: // 九成新
                            dbLevel = 9;
                            break;
                        case 3: // 八成新
                            dbLevel = 8;
                            break;
                        case 4: // 七成新
                            dbLevel = 7;
                            break;
                        case 5: // 六成新以下（包括六成、五成、四成、三成）
                            // 对于"六成新以下"，需要使用IN查询，包含3,4,5,6
                            params.put("levelList", Arrays.asList(3, 4, 5, 6));
                            break;
                        default:
                            dbLevel = level;
                    }
                    if (dbLevel != null) {
                        params.put("level", dbLevel);
                    }
                }
                params.put("start", 0);
                params.put("pageSize", 12);
                
                shopInformations = shopInformationService.selectByMultiCondition(params);
                counts = shopInformationService.countByMultiCondition(params);
                
                // 已修改：保存筛选条件，用于前端回显
                model.addAttribute("selectedSort", sort);
                model.addAttribute("selectedCampus", campus);
                model.addAttribute("selectedLevel", level);
            } else {
                // 默认查询
                shopInformations = selectTen(1, 12);
                counts = getShopCounts();
            }
            
            List<ShopInformationBean> list = new ArrayList<>();
            model.addAttribute("shopInformationCounts", counts);

            // ✅ 修复：添加空值检查
            if (shopInformations != null && !shopInformations.isEmpty()) {
                String sortName;
                for (ShopInformation shopInformation : shopInformations) {
                    try {
                        int sortId = shopInformation.getSort(); // 已修改：修复变量名冲突
                        // ✅ 修复：安全获取分类名称
                        sortName = getSortNameSafely(sortId);
                        ShopInformationBean shopInformationBean = new ShopInformationBean();
                        shopInformationBean.setId(shopInformation.getId());
                        shopInformationBean.setName(shopInformation.getName());
                        shopInformationBean.setLevel(shopInformation.getLevel());
                        shopInformationBean.setRemark(shopInformation.getRemark());
                        shopInformationBean.setPrice(shopInformation.getPrice().doubleValue());
                        shopInformationBean.setSort(sortName);
                        shopInformationBean.setQuantity(shopInformation.getQuantity());
                        shopInformationBean.setTransaction(shopInformation.getTransaction());
                        shopInformationBean.setUid(shopInformation.getUid());
                        shopInformationBean.setImage(shopInformation.getImage());
                        list.add(shopInformationBean);
                    } catch (Exception e) {
                        // ✅ 单个商品处理失败不影响其他商品
                        System.err.println("处理商品失败，ID: " + shopInformation.getId() + ", 错误: " + e.getMessage());
                        e.printStackTrace();
                    }
                }
            }

            model.addAttribute("shopInformationBean", list);
            System.out.println("✅ 商城页面加载成功，共 " + list.size() + " 件商品");
        } catch (Exception e) {
            // ✅ 修复：即使查询商品失败，也应该显示商城页面，而不是返回登录页
            e.printStackTrace();
            System.err.println("❌ 商城页面加载商品数据失败: " + e.getMessage());
            model.addAttribute("shopInformationBean", new ArrayList<>());
            model.addAttribute("shopInformationCounts", 0);
        }
        return "page/mall_page";
    }

    // ✅ 新增：安全获取分类名称的方法
    private String getSortNameSafely(int sort) {
        try {
            return getSortName(sort);
        } catch (Exception e) {
            System.err.println("获取分类名称失败，sort=" + sort + ", 错误: " + e.getMessage());
            return "未分类";
        }
    }

    //通过分类的第三层id获取全名
    private String getSortName(int sort) {
        StringBuilder stringBuffer = new StringBuilder();
        // ✅ 修复：添加空值检查，防止空指针异常
        Specific specific = selectSpecificBySort(sort);
        if (specific == null) {
            return "未分类";
        }

        int cid = specific.getCid();
        Classification classification = selectClassificationByCid(cid);
        if (classification == null) {
            return specific.getName();
        }

        int aid = classification.getAid();
        AllKinds allKinds = selectAllKindsByAid(aid);
        if (allKinds == null) {
            return classification.getName() + "-" + specific.getName();
        }

        stringBuffer.append(allKinds.getName());
        stringBuffer.append("-");
        stringBuffer.append(classification.getName());
        stringBuffer.append("-");
        stringBuffer.append(specific.getName());
//        System.out.println(sort);
        return stringBuffer.toString();
    }

    //获得分类中的第一层
    @RequestMapping(value = "/getAllKinds.do")
    @ResponseBody
    public List<AllKinds> getAllKind() {
        return getAllKinds();
    }

    //获得分类中的第二层，通过第一层的id
    @RequestMapping(value = "/getClassification.do", method = RequestMethod.POST)
    @ResponseBody
    public List<Classification> getClassificationByAid(@RequestParam int id) {
        return selectAllClassification(id);
    }

    //通过第二层的id获取对应的第三层
    @RequestMapping(value = "/getSpecific.do")
    @ResponseBody
    public List<Specific> getSpecificByCid(@RequestParam int id) {
        return selectAllSpecific(id);
    }

    //get the shops counts
    @RequestMapping(value = "/getShopsCounts.do")
    @ResponseBody
    public Map getShopsCounts() {
        Map<String, Integer> map = new HashMap<>();
        int counts = 0;
        try {
            counts = shopInformationService.getCounts();
        } catch (Exception e) {
            e.printStackTrace();
            map.put("counts", counts);
            return map;
        }
        map.put("counts", counts);
        return map;
    }

    @RequestMapping(value = "/getShops.do")
    @ResponseBody
    public List getShops(@RequestParam int start) {
        List<ShopInformation> list = new ArrayList<>();
        try {
            int end = 12;
            list = selectTen(start, end);
        } catch (Exception e) {
            e.printStackTrace();
            return list;
        }
        return list;
    }


    //获取商品，分页,一次性获取end个
    private List<ShopInformation> selectTen(int start, int end) {
        Map map = new HashMap();
        map.put("start", (start - 1) * end);
        map.put("end", end);
        List<ShopInformation> list = shopInformationService.selectTen(map);
        return list;
    }

    //获取最详细的分类，第三层
    private Specific selectSpecificBySort(int sort) {
        return specificeService.selectByPrimaryKey(sort);
    }

    //获得第二层分类
    private Classification selectClassificationByCid(int cid) {
        return classificationService.selectByPrimaryKey(cid);
    }

    //获得第一层分类
    private AllKinds selectAllKindsByAid(int aid) {
        return allKindsService.selectByPrimaryKey(aid);
    }

    //获得第一层所有
    private List<AllKinds> getAllKinds() {
        return allKindsService.selectAll();
    }

    //根据第一层的id获取该层下的第二层
    private List<Classification> selectAllClassification(int aid) {
        return classificationService.selectByAid(aid);
    }

    //根据第二层的id获取其对应的第三层所有id
    private List<Specific> selectAllSpecific(int cid) {
        return specificeService.selectByCid(cid);
    }

    //获得商品总页数
    private int getShopCounts() {
        return shopInformationService.getCounts();
    }

    //获得商品留言总页数
    private int getShopContextCounts(int sid) {
        return shopContextService.getCounts(sid);
    }

    //获得商品留言，10条
    private List<ShopContext> selectShopContextBySid(int sid, int start) {
        return shopContextService.findById(sid, (start - 1) * 10);
    }
    
    // 已修改：根据第一层分类ID（allkinds的id），获取该大类下的所有第三层分类ID列表
    private List<Integer> getSpecificIdsByAllKindsId(Integer allKindsId) {
        List<Integer> specificIds = new ArrayList<>();
        try {
            // 1. 获取该大类下的所有第二层分类（classification）
            List<Classification> classifications = classificationService.selectByAid(allKindsId);
            if (classifications == null || classifications.isEmpty()) {
                System.out.println("⚠️ 大类ID " + allKindsId + " 下没有找到第二层分类");
                return specificIds;
            }
            
            // 2. 遍历每个第二层分类，获取其下的所有第三层分类（specific）
            for (Classification classification : classifications) {
                List<Specific> specifics = specificeService.selectByCid(classification.getId());
                if (specifics != null && !specifics.isEmpty()) {
                    for (Specific specific : specifics) {
                        specificIds.add(specific.getId());
                    }
                }
            }
            
            System.out.println("✅ 大类ID " + allKindsId + " 下共找到 " + specificIds.size() + " 个第三层分类");
        } catch (Exception e) {
            System.err.println("❌ 获取大类下的分类ID列表失败，allKindsId=" + allKindsId + ", 错误: " + e.getMessage());
            e.printStackTrace();
        }
        return specificIds;
    }
}
