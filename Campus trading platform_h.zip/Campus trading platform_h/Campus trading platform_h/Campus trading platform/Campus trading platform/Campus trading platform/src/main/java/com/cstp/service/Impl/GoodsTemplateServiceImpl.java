package com.cstp.service.Impl;

import com.cstp.dao.GoodsTemplateMapper;
import com.cstp.pojo.GoodsTemplate;
import com.cstp.service.GoodsTemplateService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class GoodsTemplateServiceImpl implements GoodsTemplateService {

    @Resource
    private GoodsTemplateMapper goodsTemplateMapper;

    @Override
    public int deleteByPrimaryKey(Integer templateId) {
        return goodsTemplateMapper.deleteByPrimaryKey(templateId);
    }

    @Override
    public int insert(GoodsTemplate record) {
        return goodsTemplateMapper.insert(record);
    }

    @Override
    public int insertSelective(GoodsTemplate record) {
        return goodsTemplateMapper.insertSelective(record);
    }

    @Override
    public GoodsTemplate selectByPrimaryKey(Integer templateId) {
        return goodsTemplateMapper.selectByPrimaryKey(templateId);
    }

    @Override
    public int updateByPrimaryKeySelective(GoodsTemplate record) {
        return goodsTemplateMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public int updateByPrimaryKey(GoodsTemplate record) {
        return goodsTemplateMapper.updateByPrimaryKey(record);
    }

    @Override
    public List<GoodsTemplate> selectByUserId(Integer userId) {
        return goodsTemplateMapper.selectByUserId(userId);
    }
}

