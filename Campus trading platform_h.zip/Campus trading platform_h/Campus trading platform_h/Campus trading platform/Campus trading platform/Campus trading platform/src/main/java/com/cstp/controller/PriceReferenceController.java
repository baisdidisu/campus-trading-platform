package com.cstp.controller;

import com.cstp.pojo.ShopInformation;
import com.cstp.response.BaseResponse;
import com.cstp.service.PriceReferenceService;
import com.cstp.service.ShopInformationService;
import com.cstp.tool.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class PriceReferenceController {

    @Resource
    private PriceReferenceService priceReferenceService;

    @Resource
    private ShopInformationService shopInformationService;

    /**
     * 获取价格参考统计（发布商品时选择分类后调用）
     * @param categoryId 分类ID
     * @return 价格统计信息
     */
    @RequestMapping(value = "/goods/price/reference", method = RequestMethod.GET)
    @ResponseBody
    public BaseResponse getPriceStatistics(@RequestParam Integer categoryId) {
        try {
            if (categoryId == null || categoryId <= 0) {
                return BaseResponse.fail("分类ID无效");
            }
            
            Map<String, Object> statistics = priceReferenceService.getPriceStatisticsBySort(categoryId);
            return BaseResponse.success(statistics);
        } catch (Exception e) {
            e.printStackTrace();
            return BaseResponse.fail("查询价格统计失败");
        }
    }

    /**
     * 一键议价功能
     * @param request HTTP请求
     * @param shopId 商品ID
     * @param bargainType 议价类型（如：少5元、包邮等）
     * @return 操作结果
     */
    @RequestMapping(value = "/message/bargain/send", method = RequestMethod.POST)
    @ResponseBody
    public BaseResponse sendBargainMessage(HttpServletRequest request,
                                          @RequestParam Integer shopId,
                                          @RequestParam String bargainType) {
        try {
            // 检查用户是否登录
            Object userInfo = request.getSession().getAttribute("userInformation");
            if (StringUtils.getInstance().isNullOrEmpty(userInfo)) {
                return BaseResponse.fail("请先登录");
            }
            
            // 获取买家ID（当前登录用户）
            Integer buyerId = (Integer) request.getSession().getAttribute("uid");
            if (buyerId == null || buyerId <= 0) {
                return BaseResponse.fail("用户ID无效");
            }
            
            // 参数校验
            if (shopId == null || shopId <= 0) {
                return BaseResponse.fail("商品ID无效");
            }
            if (StringUtils.getInstance().isNullOrEmpty(bargainType)) {
                return BaseResponse.fail("议价类型不能为空");
            }
            
            // 查询商品信息获取卖家ID
            ShopInformation shopInfo = shopInformationService.selectByPrimaryKey(shopId);
            if (shopInfo == null) {
                return BaseResponse.fail("商品不存在");
            }
            Integer sellerId = shopInfo.getUid();
            
            // 不能向自己发送议价消息
            if (buyerId.equals(sellerId)) {
                return BaseResponse.fail("不能向自己发送议价消息");
            }
            
            // 发送议价消息
            boolean success = priceReferenceService.sendBargainMessage(buyerId, sellerId, shopId, bargainType);
            if (success) {
                return BaseResponse.success("议价消息已发送");
            } else {
                return BaseResponse.fail("发送议价消息失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return BaseResponse.fail("发送议价消息异常");
        }
    }
}
