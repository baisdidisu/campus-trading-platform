package com.cstp.service;

import com.cstp.pojo.GoodsTemplate;

import java.util.List;

public interface GoodsTemplateService {
    int deleteByPrimaryKey(Integer templateId);

    int insert(GoodsTemplate record);

    int insertSelective(GoodsTemplate record);

    GoodsTemplate selectByPrimaryKey(Integer templateId);

    int updateByPrimaryKeySelective(GoodsTemplate record);

    int updateByPrimaryKey(GoodsTemplate record);

    /**
     * 根据用户ID查询所有模板
     * @param userId 用户ID
     * @return 模板列表
     */
    List<GoodsTemplate> selectByUserId(Integer userId);
}

