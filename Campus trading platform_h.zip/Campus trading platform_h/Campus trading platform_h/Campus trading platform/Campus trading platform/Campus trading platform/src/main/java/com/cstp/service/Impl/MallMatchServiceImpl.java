package com.cstp.service.Impl;

import com.cstp.pojo.Message;
import com.cstp.pojo.ShopInformation;
import com.cstp.service.MallMatchService;
import com.cstp.service.MallSubscribeService;
import com.cstp.service.MessageService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class MallMatchServiceImpl implements MallMatchService {

    @Resource
    private MallSubscribeService mallSubscribeService;

    @Resource
    private MessageService messageService;

    @Override
    public int notifySubscribedUsers(ShopInformation shopInfo) {
        int notifyCount = 0;
        Set<Integer> notifiedUserIds = new HashSet<>();

        try {
            // 查询订阅了该分类的用户
            List<Integer> subscribedUserIds = mallSubscribeService.getUserIdsByCategoryId(shopInfo.getSort());

            for (Integer userId : subscribedUserIds) {
                // 排除商品发布者自己
                if (!userId.equals(shopInfo.getUid()) && !notifiedUserIds.contains(userId)) {
                    sendSubscriptionNotification(userId, shopInfo);
                    notifiedUserIds.add(userId);
                    notifyCount++;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return notifyCount;
    }

    /**
     * 发送订阅通知消息
     */
    private void sendSubscriptionNotification(Integer toUserId, ShopInformation shopInfo) {
        try {
            Message message = new Message();
            message.setFromUserId(shopInfo.getUid());
            message.setToUserId(toUserId);
            message.setContent(String.format("您订阅的分类上架了新商品：【%s】，快去看看吧！", shopInfo.getName()));
            message.setMessageType(1);
            message.setRelatedId(shopInfo.getId());
            message.setModified(new Date());
            message.setIsRead(0);
            message.setDisplay(1);

            messageService.sendMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

