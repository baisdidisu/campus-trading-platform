package com.cstp.controller;

import com.cstp.pojo.ShopInformation;
import com.cstp.pojo.UserInformation;
import com.cstp.response.BaseResponse;
import com.cstp.service.ShopInformationService;
import com.cstp.service.UserInformationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 同城筛选控制器
 * 功能：按校区筛选商品、附近商品推荐
 */
@Controller
@RequestMapping("/campus")
@Slf4j
public class CampusFilterController {

    @Resource
    private ShopInformationService shopInformationService;

    @Resource
    private UserInformationService userInformationService;

    /**
     * 按校区筛选商品
     */
    @GetMapping("/filterByCampus")
    @ResponseBody
    public BaseResponse filterByCampus(
            @RequestParam(required = false) String campus,
            @RequestParam(defaultValue = "1") Integer page,
            @RequestParam(defaultValue = "20") Integer pageSize,
            HttpServletRequest request) {
        try {
            UserInformation user = (UserInformation) request.getSession().getAttribute("userInformation");
            
            // 如果没有指定校区，使用当前用户的校区
            if (campus == null || campus.isEmpty()) {
                if (user != null && user.getCampus() != null) {
                    campus = user.getCampus();
                } else {
                    return BaseResponse.error("请先设置您的校区信息");
                }
            }

            // 获取所有商品（这里简化处理，实际应该在Mapper中实现）
            List<ShopInformation> allShops = shopInformationService.selectAll();
            
            // 筛选同校区的商品
            final String targetCampus = campus;
            List<ShopInformation> filteredShops = allShops.stream()
                .filter(shop -> {
                    // 通过卖家ID获取卖家信息
                    UserInformation seller = userInformationService.selectByPrimaryKey(shop.getUid());
                    return seller != null && targetCampus.equals(seller.getCampus());
                })
                .collect(Collectors.toList());

            // 分页处理
            int start = (page - 1) * pageSize;
            int end = Math.min(start + pageSize, filteredShops.size());
            List<ShopInformation> pagedShops = filteredShops.subList(
                Math.min(start, filteredShops.size()), 
                end
            );

            Map<String, Object> result = new HashMap<>();
            result.put("shops", pagedShops);
            result.put("total", filteredShops.size());
            result.put("page", page);
            result.put("pageSize", pageSize);
            result.put("campus", campus);

            return BaseResponse.success("查询成功", result);
        } catch (Exception e) {
            log.error("按校区筛选商品失败", e);
            return BaseResponse.error("查询失败：" + e.getMessage());
        }
    }

    /**
     * 获取附近的商品（同校区同楼栋）
     */
    @GetMapping("/nearby")
    @ResponseBody
    public BaseResponse getNearbyShops(
            @RequestParam(defaultValue = "20") Integer limit,
            HttpServletRequest request) {
        try {
            UserInformation user = (UserInformation) request.getSession().getAttribute("userInformation");
            if (user == null) {
                return BaseResponse.error("请先登录");
            }

            if (user.getCampus() == null || user.getBuilding() == null) {
                return BaseResponse.error("请先完善您的位置信息");
            }

            // 获取所有商品
            List<ShopInformation> allShops = shopInformationService.selectAll();
            
            // 筛选同校区同楼栋的商品
            List<ShopInformation> nearbyShops = allShops.stream()
                .filter(shop -> {
                    UserInformation seller = userInformationService.selectByPrimaryKey(shop.getUid());
                    if (seller == null) return false;
                    
                    // 同校区
                    boolean sameCampus = user.getCampus().equals(seller.getCampus());
                    // 同楼栋（可选）
                    boolean sameBuilding = user.getBuilding() != null && 
                                          user.getBuilding().equals(seller.getBuilding());
                    
                    return sameCampus && sameBuilding;
                })
                .limit(limit)
                .collect(Collectors.toList());

            Map<String, Object> result = new HashMap<>();
            result.put("shops", nearbyShops);
            result.put("total", nearbyShops.size());
            result.put("userCampus", user.getCampus());
            result.put("userBuilding", user.getBuilding());

            return BaseResponse.success("查询成功", result);
        } catch (Exception e) {
            log.error("查询附近商品失败", e);
            return BaseResponse.error("查询失败：" + e.getMessage());
        }
    }

    /**
     * 获取各校区的商品统计
     */
    @GetMapping("/statistics")
    @ResponseBody
    public BaseResponse getCampusStatistics() {
        try {
            List<ShopInformation> allShops = shopInformationService.selectAll();
            
            // 统计各校区的商品数量
            Map<String, Long> campusStats = new HashMap<>();
            
            for (ShopInformation shop : allShops) {
                UserInformation seller = userInformationService.selectByPrimaryKey(shop.getUid());
                if (seller != null && seller.getCampus() != null) {
                    String campus = seller.getCampus();
                    campusStats.put(campus, campusStats.getOrDefault(campus, 0L) + 1);
                }
            }

            return BaseResponse.success("查询成功", campusStats);
        } catch (Exception e) {
            log.error("查询校区统计失败", e);
            return BaseResponse.error("查询失败：" + e.getMessage());
        }
    }

    /**
     * 推荐同校区的热门商品
     */
    @GetMapping("/recommend")
    @ResponseBody
    public BaseResponse getRecommendShops(
            @RequestParam(defaultValue = "10") Integer limit,
            HttpServletRequest request) {
        try {
            UserInformation user = (UserInformation) request.getSession().getAttribute("userInformation");
            if (user == null || user.getCampus() == null) {
                // 未登录或未设置校区，返回全部热门商品
                List<ShopInformation> hotShops = shopInformationService.selectAll().stream()
                    .sorted((a, b) -> Integer.compare(b.getSales(), a.getSales()))
                    .limit(limit)
                    .collect(Collectors.toList());
                
                return BaseResponse.success("查询成功", hotShops);
            }

            // 获取同校区的热门商品
            List<ShopInformation> allShops = shopInformationService.selectAll();
            
            List<ShopInformation> recommendShops = allShops.stream()
                .filter(shop -> {
                    UserInformation seller = userInformationService.selectByPrimaryKey(shop.getUid());
                    return seller != null && user.getCampus().equals(seller.getCampus());
                })
                .sorted((a, b) -> Integer.compare(b.getSales(), a.getSales()))
                .limit(limit)
                .collect(Collectors.toList());

            Map<String, Object> result = new HashMap<>();
            result.put("shops", recommendShops);
            result.put("campus", user.getCampus());

            return BaseResponse.success("查询成功", result);
        } catch (Exception e) {
            log.error("查询推荐商品失败", e);
            return BaseResponse.error("查询失败：" + e.getMessage());
        }
    }
}

