package com.cstp.service;

import java.util.Map;

public interface PriceReferenceService {
    /**
     * 根据分类ID统计同类商品的成交价格（MIN, MAX, AVG）
     * @param sort 分类ID（对应shopinformation的sort字段）
     * @return 价格统计信息，包含minPrice, maxPrice, avgPrice
     */
    Map<String, Object> getPriceStatisticsBySort(Integer sort);

    /**
     * 发送议价消息
     * @param buyerId 买家ID
     * @param sellerId 卖家ID
     * @param shopId 商品ID
     * @param bargainType 议价类型（如：少5元、包邮等）
     * @return 是否发送成功
     */
    boolean sendBargainMessage(Integer buyerId, Integer sellerId, Integer shopId, String bargainType);
}
