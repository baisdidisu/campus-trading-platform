package com.cstp.task;

import com.cstp.pojo.OrderForm;
import com.cstp.pojo.OrderReminder;
import com.cstp.service.OrderFormService;
import com.cstp.service.OrderReminderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * 订单定时任务
 * 功能：订单到期提醒、自动处理过期订单
 */
@Component
@Slf4j
public class OrderScheduledTask {

    @Resource
    private OrderFormService orderFormService;

    @Resource
    private OrderReminderService orderReminderService;

    /**
     * 每小时检查一次待发送的提醒
     * cron表达式：每小时的第0分钟执行
     */
    @Scheduled(cron = "0 0 * * * ?")
    public void sendPendingReminders() {
        try {
            log.info("开始检查待发送的订单提醒...");
            
            List<OrderReminder> reminders = orderReminderService.selectPendingReminders();
            
            for (OrderReminder reminder : reminders) {
                try {
                    // 这里可以集成短信、邮件或站内消息服务
                    // 目前只记录日志
                    OrderForm order = orderFormService.selectByPrimaryKey(reminder.getOrderId());
                    if (order != null) {
                        log.info("订单提醒：订单ID={}, 用户ID={}, 提醒类型={}, 订单状态={}", 
                            reminder.getOrderId(), 
                            reminder.getUserId(), 
                            reminder.getReminderType(),
                            order.getOrderStatus());
                        
                        // 标记为已发送
                        orderReminderService.markAsSent(reminder.getId());
                    }
                } catch (Exception e) {
                    log.error("发送提醒失败：reminderId=" + reminder.getId(), e);
                }
            }
            
            log.info("订单提醒检查完成，共处理{}条提醒", reminders.size());
        } catch (Exception e) {
            log.error("检查订单提醒失败", e);
        }
    }

    /**
     * 每天凌晨2点检查过期订单
     * cron表达式：每天凌晨2点执行
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void handleExpiredOrders() {
        try {
            log.info("开始检查过期订单...");
            
            List<OrderForm> expiredOrders = orderFormService.selectExpiredOrders();
            
            for (OrderForm order : expiredOrders) {
                try {
                    // 自动取消过期的待处理订单
                    if ("pending".equals(order.getOrderStatus())) {
                        orderFormService.cancelOrder(order.getId());
                        log.info("自动取消过期订单：订单ID={}, 用户ID={}", order.getId(), order.getUid());
                    }
                } catch (Exception e) {
                    log.error("处理过期订单失败：orderId=" + order.getId(), e);
                }
            }
            
            log.info("过期订单处理完成，共处理{}个订单", expiredOrders.size());
        } catch (Exception e) {
            log.error("检查过期订单失败", e);
        }
    }

    /**
     * 每6小时检查即将过期的订单（24小时内）
     * cron表达式：每天0点、6点、12点、18点执行
     */
    @Scheduled(cron = "0 0 0,6,12,18 * * ?")
    public void checkOrdersNearExpire() {
        try {
            log.info("开始检查即将过期的订单...");
            
            List<OrderForm> nearExpireOrders = orderFormService.selectOrdersNearExpire(24);
            
            log.info("发现{}个即将过期的订单", nearExpireOrders.size());
            
            for (OrderForm order : nearExpireOrders) {
                log.info("即将过期订单提醒：订单ID={}, 用户ID={}, 过期时间={}", 
                    order.getId(), 
                    order.getUid(), 
                    order.getExpireTime());
            }
        } catch (Exception e) {
            log.error("检查即将过期订单失败", e);
        }
    }
}

