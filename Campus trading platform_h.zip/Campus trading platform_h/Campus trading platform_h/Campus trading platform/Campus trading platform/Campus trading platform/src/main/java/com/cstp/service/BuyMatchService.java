package com.cstp.service;

import com.cstp.pojo.ShopInformation;

public interface BuyMatchService {
    /**
     * 当商品发布成功后，触发匹配推送
     * 1. 模糊查询求购表，找到匹配的求购者
     * 2. 查询订阅了该分类的用户
     * 3. 向上述用户发送提醒消息
     * @param shopInfo 发布的商品信息
     * @return 发送消息的数量
     */
    int matchAndNotify(ShopInformation shopInfo);
}

