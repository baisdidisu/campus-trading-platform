package com.cstp.service;

public interface MessageReminderService {
    /**
     * 当商品价格降低时，向收藏该商品的用户推送降价提醒
     * @param shopId 商品ID
     * @param oldPrice 原价格
     * @param newPrice 新价格
     * @return 发送消息的数量
     */
    int notifyPriceDrop(Integer shopId, Double oldPrice, Double newPrice);

    /**
     * 定时任务：查询发布超过30天的商品，推送过期提醒
     * @return 发送消息的数量
     */
    int notifyExpiredGoods();
}

