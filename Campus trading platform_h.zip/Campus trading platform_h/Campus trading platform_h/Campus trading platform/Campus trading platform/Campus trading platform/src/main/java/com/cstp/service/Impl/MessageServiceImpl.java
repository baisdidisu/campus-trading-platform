package com.cstp.service.Impl;

import com.cstp.dao.MessageMapper;
import com.cstp.pojo.Message;
import com.cstp.service.MessageService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class MessageServiceImpl implements MessageService {

    @Resource
    private MessageMapper messageMapper;

    @Override
    public int sendMessage(Message message) {
        if (message.getModified() == null) {
            message.setModified(new Date());
        }
        if (message.getIsRead() == null) {
            message.setIsRead(0);
        }
        if (message.getDisplay() == null) {
            message.setDisplay(1);
        }
        if (message.getMessageType() == null) {
            message.setMessageType(1); // 默认为交易消息
        }
        return messageMapper.insertSelective(message);
    }

    @Override
    public List<Message> getMessageList(Integer toUserId, Integer messageType, Integer page, Integer pageSize) {
        if (page == null || page < 1) {
            page = 1;
        }
        if (pageSize == null || pageSize < 1) {
            pageSize = 10;
        }
        int start = (page - 1) * pageSize;
        return messageMapper.selectByToUserId(toUserId, messageType, start, pageSize);
    }

    @Override
    public int countUnreadMessages(Integer toUserId, Integer messageType) {
        return messageMapper.countUnread(toUserId, messageType);
    }

    @Override
    public int markAsRead(Integer messageId) {
        return messageMapper.markAsRead(messageId);
    }
}

