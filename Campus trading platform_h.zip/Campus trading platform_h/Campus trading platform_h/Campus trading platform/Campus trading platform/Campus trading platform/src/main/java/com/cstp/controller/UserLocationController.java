package com.cstp.controller;

import com.cstp.pojo.UserInformation;
import com.cstp.response.BaseResponse;
import com.cstp.service.UserInformationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 用户定位控制器
 * 功能：校园定位、位置更新
 */
@Controller
@RequestMapping("/location")
@Slf4j
public class UserLocationController {

    @Resource
    private UserInformationService userInformationService;

    /**
     * 更新用户位置信息
     */
    @PostMapping("/update")
    @ResponseBody
    public BaseResponse updateLocation(@RequestBody Map<String, Object> locationData, HttpServletRequest request) {
        try {
            UserInformation user = (UserInformation) request.getSession().getAttribute("userInformation");
            if (user == null) {
                return BaseResponse.error("请先登录");
            }

            // 更新位置信息
            UserInformation updateUser = new UserInformation();
            updateUser.setId(user.getId());
            
            // 已修改：仅更新校区信息，移除楼栋、房间号、经纬度和更新时间
            if (locationData.containsKey("campus")) {
                updateUser.setCampus((String) locationData.get("campus"));
            }
            // 已移除：楼栋、房间号、经纬度和更新时间的更新
            // if (locationData.containsKey("building")) {
            //     updateUser.setBuilding((String) locationData.get("building"));
            // }
            // if (locationData.containsKey("roomNumber")) {
            //     updateUser.setRoomNumber((String) locationData.get("roomNumber"));
            // }
            // if (locationData.containsKey("latitude")) {
            //     updateUser.setLatitude(Double.parseDouble(locationData.get("latitude").toString()));
            // }
            // if (locationData.containsKey("longitude")) {
            //     updateUser.setLongitude(Double.parseDouble(locationData.get("longitude").toString()));
            // }
            // updateUser.setLocationUpdated(new Date());

            int result = userInformationService.updateByPrimaryKeySelective(updateUser);
            
            if (result > 0) {
                // 更新session中的用户信息
                // 已修改：确保从数据库获取完整的用户信息，避免session中的用户信息不完整
                UserInformation updatedUser = userInformationService.selectByPrimaryKey(user.getId());
                if (updatedUser != null) {
                    // 确保保留session中的uid，避免丢失
                    Integer uid = (Integer) request.getSession().getAttribute("uid");
                    if (uid == null && updatedUser.getId() != null) {
                        request.getSession().setAttribute("uid", updatedUser.getId());
                    }
                    request.getSession().setAttribute("userInformation", updatedUser);
                } else {
                    log.error("位置更新后无法获取用户信息，用户ID: {}", user.getId());
                    return BaseResponse.error("位置更新成功，但获取用户信息失败");
                }
                
                // 已修改：返回位置信息的Map，而不是整个UserInformation对象
                Map<String, Object> location = new HashMap<>();
                location.put("campus", updatedUser.getCampus());
                
                return BaseResponse.success("位置更新成功", location);
            } else {
                return BaseResponse.error("位置更新失败");
            }
        } catch (Exception e) {
            log.error("更新位置失败", e);
            return BaseResponse.error("位置更新失败：" + e.getMessage());
        }
    }

    /**
     * 获取用户位置信息
     */
    @GetMapping("/get")
    @ResponseBody
    public BaseResponse getLocation(HttpServletRequest request) {
        try {
            UserInformation user = (UserInformation) request.getSession().getAttribute("userInformation");
            if (user == null) {
                return BaseResponse.error("请先登录");
            }

            UserInformation userInfo = userInformationService.selectByPrimaryKey(user.getId());
            
            // 已修改：仅返回校区信息，移除楼栋、房间号、经纬度和更新时间
            Map<String, Object> location = new HashMap<>();
            location.put("campus", userInfo.getCampus());
            // 已移除：楼栋、房间号、经纬度和更新时间的返回
            // location.put("building", userInfo.getBuilding());
            // location.put("roomNumber", userInfo.getRoomNumber());
            // location.put("latitude", userInfo.getLatitude());
            // location.put("longitude", userInfo.getLongitude());
            // location.put("locationUpdated", userInfo.getLocationUpdated());

            return BaseResponse.success("查询成功", location);
        } catch (Exception e) {
            log.error("查询位置失败", e);
            return BaseResponse.error("查询位置失败：" + e.getMessage());
        }
    }

    /**
     * 获取所有校区列表
     */
    @GetMapping("/campusList")
    @ResponseBody
    public BaseResponse getCampusList() {
        try {
            // 已修改：校区列表改为南校区、新校区、本部、医学院、铁道学院
            String[] campusList = {
                "南校区",
                "新校区",
                "本部",
                "医学院",
                "铁道学院"
            };
            
            return BaseResponse.success("查询成功", campusList);
        } catch (Exception e) {
            log.error("查询校区列表失败", e);
            return BaseResponse.error("查询失败：" + e.getMessage());
        }
    }

    /**
     * 快速设置常用地址
     */
    @PostMapping("/setQuickAddress")
    @ResponseBody
    public BaseResponse setQuickAddress(
            @RequestParam String campus,
            @RequestParam String building,
            @RequestParam(required = false) String roomNumber,
            HttpServletRequest request) {
        try {
            UserInformation user = (UserInformation) request.getSession().getAttribute("userInformation");
            if (user == null) {
                return BaseResponse.error("请先登录");
            }

            // 已修改：仅更新校区信息，移除楼栋、房间号和更新时间
            UserInformation updateUser = new UserInformation();
            updateUser.setId(user.getId());
            updateUser.setCampus(campus);
            // 已移除：楼栋、房间号和更新时间的更新
            // updateUser.setBuilding(building);
            // updateUser.setRoomNumber(roomNumber);
            // updateUser.setLocationUpdated(new Date());

            int result = userInformationService.updateByPrimaryKeySelective(updateUser);
            
            if (result > 0) {
                UserInformation updatedUser = userInformationService.selectByPrimaryKey(user.getId());
                request.getSession().setAttribute("userInformation", updatedUser);
                
                return BaseResponse.success("地址设置成功", updatedUser);
            } else {
                return BaseResponse.error("地址设置失败");
            }
        } catch (Exception e) {
            log.error("设置地址失败", e);
            return BaseResponse.error("设置地址失败：" + e.getMessage());
        }
    }
}

