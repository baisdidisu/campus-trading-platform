package com.cstp.controller;

import com.cstp.response.BaseResponse;
import com.cstp.service.MallSubscribeService;
import com.cstp.tool.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Controller
public class MallSubscribeController {

    @Resource
    private MallSubscribeService mallSubscribeService;

    /**
     * 订阅某个分类的商品信息
     * @param request HTTP请求
     * @param categoryId 分类ID
     * @return 操作结果
     */
    @RequestMapping(value = "/subscribeMallCategory.do", method = RequestMethod.POST)
    @ResponseBody
    public BaseResponse subscribeCategory(HttpServletRequest request,
                                       @RequestParam Integer categoryId) {
        try {
            // 检查用户是否登录
            Object userInfo = request.getSession().getAttribute("userInformation");
            if (StringUtils.getInstance().isNullOrEmpty(userInfo)) {
                return BaseResponse.fail("请先登录");
            }
            
            Integer userId = (Integer) request.getSession().getAttribute("uid");
            if (userId == null || userId <= 0) {
                return BaseResponse.fail("用户ID无效");
            }
            
            if (categoryId == null || categoryId <= 0) {
                return BaseResponse.fail("分类ID无效");
            }
            
            boolean success = mallSubscribeService.subscribeCategory(userId, categoryId);
            if (success) {
                return BaseResponse.success("订阅成功");
            } else {
                return BaseResponse.fail("已订阅该分类");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return BaseResponse.fail("订阅异常");
        }
    }

    /**
     * 取消订阅某个分类
     * @param request HTTP请求
     * @param categoryId 分类ID
     * @return 操作结果
     */
    @RequestMapping(value = "/unsubscribeMallCategory.do", method = RequestMethod.POST)
    @ResponseBody
    public BaseResponse unsubscribeCategory(HttpServletRequest request,
                                          @RequestParam Integer categoryId) {
        try {
            // 检查用户是否登录
            Object userInfo = request.getSession().getAttribute("userInformation");
            if (StringUtils.getInstance().isNullOrEmpty(userInfo)) {
                return BaseResponse.fail("请先登录");
            }
            
            Integer userId = (Integer) request.getSession().getAttribute("uid");
            if (userId == null || userId <= 0) {
                return BaseResponse.fail("用户ID无效");
            }
            
            if (categoryId == null || categoryId <= 0) {
                return BaseResponse.fail("分类ID无效");
            }
            
            boolean success = mallSubscribeService.unsubscribeCategory(userId, categoryId);
            if (success) {
                return BaseResponse.success("取消订阅成功");
            } else {
                return BaseResponse.fail("未订阅该分类或取消失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return BaseResponse.fail("取消订阅异常");
        }
    }

    /**
     * 获取用户订阅的分类列表
     * @param request HTTP请求
     * @return 分类ID列表
     */
    @RequestMapping(value = "/getMallSubscriptions.do", method = RequestMethod.GET)
    @ResponseBody
    public BaseResponse getSubscriptions(HttpServletRequest request) {
        try {
            // 检查用户是否登录
            Object userInfo = request.getSession().getAttribute("userInformation");
            if (StringUtils.getInstance().isNullOrEmpty(userInfo)) {
                return BaseResponse.fail("请先登录");
            }
            
            Integer userId = (Integer) request.getSession().getAttribute("uid");
            if (userId == null || userId <= 0) {
                return BaseResponse.fail("用户ID无效");
            }
            
            return BaseResponse.success(mallSubscribeService.getCategoryIdsByUserId(userId));
        } catch (Exception e) {
            e.printStackTrace();
            return BaseResponse.fail("获取订阅列表失败");
        }
    }
}
