package com.cstp.dao;

import com.cstp.pojo.Message;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface MessageMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Message record);

    int insertSelective(Message record);

    Message selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Message record);

    int updateByPrimaryKey(Message record);

    /**
     * 根据接收者用户ID查询消息列表
     * @param toUserId 接收者用户ID
     * @param messageType 消息类型（可选，null表示查询所有类型）
     * @param start 起始位置
     * @param limit 限制数量
     * @return 消息列表
     */
    List<Message> selectByToUserId(@Param("toUserId") Integer toUserId,
                                   @Param("messageType") Integer messageType,
                                   @Param("start") Integer start,
                                   @Param("limit") Integer limit);

    /**
     * 统计未读消息数量
     * @param toUserId 接收者用户ID
     * @param messageType 消息类型（可选）
     * @return 未读消息数量
     */
    int countUnread(@Param("toUserId") Integer toUserId,
                     @Param("messageType") Integer messageType);

    /**
     * 标记消息为已读
     * @param id 消息ID
     * @return 更新行数
     */
    int markAsRead(Integer id);
}

