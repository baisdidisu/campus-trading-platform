package com.cstp.controller;

import com.cstp.pojo.UserInformation; // ✅ 修正：改为pojo包下的实体类
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

/**
 * 页面路由控制器
 * 处理新功能页面的访问
 */
@Controller
@RequestMapping("/page")
public class PageController {

    /**
     * 创建订单页面 ✅ 新增：未登录自动跳转登录页
     */
    @GetMapping("/create_order.html")
    public String createOrderPage(HttpSession session, Model model) {
        return getLoginUserAndJump(session, model, "page/create_order");
    }

    /**
     * 我的订单页面 ✅ 新增：未登录自动跳转登录页
     */
    @GetMapping("/my_orders.html")
    public String myOrdersPage(HttpSession session, Model model) {
        return getLoginUserAndJump(session, model, "page/my_orders");
    }

    /**
     * 位置设置页面 ✅ 新增：未登录自动跳转登录页
     */
    @GetMapping("/location_settings.html")
    public String locationSettingsPage(HttpSession session, Model model) {
        return getLoginUserAndJump(session, model, "page/location_settings");
    }

    /**
     * ✅ 通用登录校验方法（抽离复用，避免代码冗余）
     * @param session 会话对象
     * @param model 数据模型
     * @param targetPage 目标跳转页面
     * @return 页面路径 / 登录页重定向
     */
    private String getLoginUserAndJump(HttpSession session, Model model, String targetPage) {
        // 获取当前登录用户
        UserInformation userInformation = (UserInformation) session.getAttribute("userInformation");
        if (userInformation != null) {
            model.addAttribute("userInformation", userInformation);
            return targetPage; // 已登录，跳转目标页面
        }
        // 未登录，强制跳转登录页（和项目原有登录逻辑保持一致）
        return "redirect:/login.do";
    }
}