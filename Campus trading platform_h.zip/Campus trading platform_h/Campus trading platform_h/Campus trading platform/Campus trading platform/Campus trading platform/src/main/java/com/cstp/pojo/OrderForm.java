package com.cstp.pojo;

import java.io.Serializable;
import java.util.Date;

public class OrderForm implements Serializable {
    private Integer id;

    private Date modified;

    private Integer display;

    private Integer uid;

    private String address;

    private String context;

    // 新增字段 - 自提面交功能
    private String deliveryType;  // 交付方式: express-快递, pickup-自提, meetup-面交

    private String pickupLocation;  // 自提地点

    private Date meetupTime;  // 面交时间

    private String meetupLocation;  // 面交地点

    private String orderStatus;  // 订单状态: pending-待处理, confirmed-已确认, completed-已完成, cancelled-已取消

    private String buyerPhone;  // 买家联系电话

    private String sellerPhone;  // 卖家联系电话

    private String orderNotes;  // 订单备注

    private Date createdTime;  // 订单创建时间

    private Date completedTime;  // 订单完成时间

    private Date expireTime;  // 订单过期时间

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getModified() {
        return modified == null ? null : (Date) modified.clone();
    }

    public void setModified(Date modified) {
        this.modified = modified == null ? null : (Date) modified.clone();
    }

    public Integer getDisplay() {
        return display;
    }

    public void setDisplay(Integer display) {
        this.display = display;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context == null ? null : context.trim();
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType == null ? null : deliveryType.trim();
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation == null ? null : pickupLocation.trim();
    }

    public Date getMeetupTime() {
        return meetupTime == null ? null : (Date) meetupTime.clone();
    }

    public void setMeetupTime(Date meetupTime) {
        this.meetupTime = meetupTime == null ? null : (Date) meetupTime.clone();
    }

    public String getMeetupLocation() {
        return meetupLocation;
    }

    public void setMeetupLocation(String meetupLocation) {
        this.meetupLocation = meetupLocation == null ? null : meetupLocation.trim();
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus == null ? null : orderStatus.trim();
    }

    public String getBuyerPhone() {
        return buyerPhone;
    }

    public void setBuyerPhone(String buyerPhone) {
        this.buyerPhone = buyerPhone == null ? null : buyerPhone.trim();
    }

    public String getSellerPhone() {
        return sellerPhone;
    }

    public void setSellerPhone(String sellerPhone) {
        this.sellerPhone = sellerPhone == null ? null : sellerPhone.trim();
    }

    public String getOrderNotes() {
        return orderNotes;
    }

    public void setOrderNotes(String orderNotes) {
        this.orderNotes = orderNotes == null ? null : orderNotes.trim();
    }

    public Date getCreatedTime() {
        return createdTime == null ? null : (Date) createdTime.clone();
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime == null ? null : (Date) createdTime.clone();
    }

    public Date getCompletedTime() {
        return completedTime == null ? null : (Date) completedTime.clone();
    }

    public void setCompletedTime(Date completedTime) {
        this.completedTime = completedTime == null ? null : (Date) completedTime.clone();
    }

    public Date getExpireTime() {
        return expireTime == null ? null : (Date) expireTime.clone();
    }

    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime == null ? null : (Date) expireTime.clone();
    }
}