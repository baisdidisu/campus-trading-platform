package com.cstp.service.Impl;

import com.cstp.dao.UserWantMapper;
import com.cstp.pojo.Message;
import com.cstp.pojo.ShopInformation;
import com.cstp.pojo.UserWant;
import com.cstp.service.BuyMatchService;
import com.cstp.service.BuySubscribeService;
import com.cstp.service.MessageService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class BuyMatchServiceImpl implements BuyMatchService {

    @Resource
    private UserWantMapper userWantMapper;

    @Resource
    private BuySubscribeService buySubscribeService;

    @Resource
    private MessageService messageService;

    @Override
    public int matchAndNotify(ShopInformation shopInfo) {
        int notifyCount = 0;
        Set<Integer> notifiedUserIds = new HashSet<>(); // 避免重复通知
        
        try {
            // 1. 模糊查询求购表：按商品名称和分类ID查询
            List<UserWant> matchedWants = userWantMapper.selectByNameAndSort(
                shopInfo.getName(), shopInfo.getSort());
            
            // 向匹配的求购者发送消息
            for (UserWant want : matchedWants) {
                // 排除商品发布者自己
                if (!want.getUid().equals(shopInfo.getUid()) && 
                    !notifiedUserIds.contains(want.getUid())) {
                    sendMatchNotification(want.getUid(), shopInfo);
                    notifiedUserIds.add(want.getUid());
                    notifyCount++;
                }
            }
            
            // 2. 查询订阅了该分类的用户
            List<Integer> subscribedUserIds = buySubscribeService.getUserIdsByCategoryId(shopInfo.getSort());
            
            // 向订阅用户发送消息
            for (Integer userId : subscribedUserIds) {
                // 排除商品发布者自己和已经通知过的用户
                if (!userId.equals(shopInfo.getUid()) && 
                    !notifiedUserIds.contains(userId)) {
                    sendMatchNotification(userId, shopInfo);
                    notifiedUserIds.add(userId);
                    notifyCount++;
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return notifyCount;
    }

    /**
     * 发送匹配通知消息
     * @param toUserId 接收者用户ID
     * @param shopInfo 商品信息
     */
    private void sendMatchNotification(Integer toUserId, ShopInformation shopInfo) {
        try {
            Message message = new Message();
            message.setFromUserId(shopInfo.getUid()); // 商品发布者
            message.setToUserId(toUserId);
            message.setContent(String.format("有人发布了您订阅的求购信息相关商品：【%s】，请及时查看！", shopInfo.getName()));
            message.setMessageType(1); // 交易消息
            message.setRelatedId(shopInfo.getId()); // 关联商品ID
            message.setModified(new Date());
            message.setIsRead(0);
            message.setDisplay(1);
            
            messageService.sendMessage(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

