package com.cstp.dao;

import com.cstp.pojo.OrderForm;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderFormMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(OrderForm record);

    int insertSelective(OrderForm record);

    OrderForm selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(OrderForm record);

    int updateByPrimaryKey(OrderForm record);

    int getCounts(int uid);

    List<OrderForm> selectByUid(@Param("uid") int uid, @Param("offset") int offset);
}