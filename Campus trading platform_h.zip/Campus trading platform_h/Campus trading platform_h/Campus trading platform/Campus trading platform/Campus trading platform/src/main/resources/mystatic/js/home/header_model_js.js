$(function () {
    // 已修改：优化body点击事件处理，防止白屏和意外行为
    $('body').click(function (e) {
        // 检查点击的目标元素，避免点击交互元素时触发
        var $target = $(e.target);
        // 如果点击的是链接、按钮、输入框等交互元素，不处理
        if ($target.is('a, button, input, select, textarea, .subscribe_btn, .update_button') || 
            $target.closest('a, button, .subscribe_btn, .update_button').length > 0) {
            return;
        }
        
        if (e.clientX > 150 || e.clientY > 300) {
            if ($('.short_nav_show').is(":visible")) {
                $('.short_nav_show').animate({
                    opacity: 0,
                    height: 0
                }, 500, function () {
                    $(this).hide(0);
                });
            }
            if ($('.personal_nav').is(":visible")) {
                // 已修改：使用正确的选择器，而不是$(this)
                $('.personal_nav').animate({height: '0%'}, 300, function() {
                    $(this).hide(0);
                });
            }
        }
    });
    $(window).scroll(function () {
        //输出垂直的滚动距离
        var scroll_length = $(this).scrollTop();
//                根据滚动的距离分别修改透明度
        if (scroll_length > 5 && scroll_length < 80) {
            var op_length = (80 - scroll_length);
            if (op_length >= 0) {
                var opacity_o = op_length / 80;
                if (opacity_o < 0.2) {
                    opacity_o = 0.2;
                }
                $('.my_nav').css({opacity: (opacity_o - 0.2)});
                $('.short_nav').css({opacity: (1 - opacity_o)});
            }
        } else if (scroll_length < 5) {
            $('.my_nav').css({opacity: 1});
            $('.short_nav').css({opacity: (0)});
        } else if (scroll_length > 80 && scroll_length < 550) {
            $('.short_nav').css({opacity: (1)});
            var op_length = 550 - scroll_length;
            var op = op_length / 480;
            if (op < 0) {
                op = 0;
            }
            $('.my_slider').css({opacity: op});
        }
    });

    $('.nav_search_input').bind("focus", function () {
        $(this).animate({width: "15%", marginLeft: "20%"}, 800);
    });

    $('.nav_search_input').bind("blur", function () {
        if ($(this).val() == '')
            $(this).animate({width: "5em", marginLeft: "25%"}, 800);
    });

    $('.search_icon').click(function () {

    });
    $('.short_nav').click(function () {
        if ($('.short_nav').css('opacity') > 0.5) {
            if ($('.short_nav_show').is(":visible")) {
                $('.short_nav_show').animate({
                    opacity: 0,
                    height: 0
                }, 500, function () {
                    $(this).hide(0);
                });
            } else {
                $('.short_nav_show').show(0).css({opacity: 0, height: 0}).animate({
                    opacity: 1,
                    height: "30%"
                }, 500).show(0);
            }
        }
    });
    $('.user_name_a').mouseenter(function () {
        if (!$('.personal_nav').is(":visible")) {
            $('.personal_nav').show(0).animate({height: '41%'}, 500);
        }
    });
    $('.personal_nav').mouseleave(function () {
        if ($('.personal_nav').is(":visible")) {
            $(this).animate({height: '0%'}, 300).hide(0);
        }
    });
    $('.search_icon').click(function () {
        var name = $('.nav_search_input').val();
        window.location.href = '/findShopByName.do?name=' + name;
    });
});
jQuery(document).ready(function ($) {
    // if (window.history && window.history.pushState) {
    //     $(window).on('popstate', function () {
    //         var hashLocation = location.hash;
    //         var hashSplit = hashLocation.split("#!/");
    //         var hashName = hashSplit[1];
    //         if (hashName !== '') {
    //             var hash = window.location.hash;
    //             if (hash === '') {
    //                 // alert("Back button isn't supported. You are leaving this application on next clicking the back button");
    //                 window.history.pushState('forward', null,'./?cstpandXYF=后退不了了吧，我故意设置的');
    //             }
    //         }
    //     });
    //     window.history.pushState('forward', '/?cstp','./?cstpandXYF='+new Date().getTime());
    // }
    //监听关闭事件
    // 已修改：优化onbeforeunload事件，只在真正关闭页面时触发，避免意外跳转导致白屏
    var isNavigatingAway = false;
    window.onbeforeunload = function (e) {
        // 只有在真正关闭页面或刷新时才执行logout
        // 如果是内部导航（如点击链接），不执行
        if (!isNavigatingAway) {
            // 使用异步方式，避免阻塞页面关闭
            setTimeout(function() {
                if (document.visibilityState === 'hidden') {
                    // 使用navigator.sendBeacon确保请求能够发送
                    if (navigator.sendBeacon) {
                        navigator.sendBeacon('/logout.do');
                    } else {
                        // 降级方案：使用同步XMLHttpRequest（仅在页面关闭时）
                        var xhr = new XMLHttpRequest();
                        xhr.open('GET', '/logout.do', false);
                        try {
                            xhr.send();
                        } catch(e) {
                            // 忽略错误
                        }
                    }
                }
            }, 0);
        }
    };
    
    // 监听内部链接点击，标记为内部导航
    $(document).on('click', 'a[href^="/"], a[href^="./"], a[href^="../"]', function() {
        isNavigatingAway = true;
        setTimeout(function() {
            isNavigatingAway = false;
        }, 1000);
    });
    var host = window.location.host;
    var me = new Date().getTime();
    var websocket = new WebSocket("ws://" + host + "/sockjs/webSocketIMServer");
    var phone = $('#user_name_a').attr('value');
    // 已修改：添加标志，用于在位置更新时暂时忽略WebSocket错误
    var isUpdatingLocation = false;
    var ignoreWebSocketErrorUntil = 0;
    
    // 暴露函数供外部调用，用于在位置更新时设置标志
    window.setLocationUpdating = function(updating) {
        isUpdatingLocation = updating;
        if (updating) {
            // 已修改：延长忽略窗口到15秒，确保位置更新后页面跳转时不会被误判
            ignoreWebSocketErrorUntil = new Date().getTime() + 15000;
            // 同时在localStorage中存储，确保跨页面也能识别
            try {
                localStorage.setItem('locationUpdating', 'true');
                localStorage.setItem('locationUpdateTime', new Date().getTime().toString());
            } catch(e) {
                console.log('localStorage not available');
            }
        } else {
            // 清除localStorage中的标志
            try {
                localStorage.removeItem('locationUpdating');
                localStorage.removeItem('locationUpdateTime');
            } catch(e) {
                console.log('localStorage not available');
            }
        }
    };
    
    // 页面加载时检查localStorage中的位置更新标志
    $(document).ready(function() {
        try {
            var storedTime = localStorage.getItem('locationUpdateTime');
            if (storedTime) {
                var storedTimeNum = parseInt(storedTime);
                var currentTime = new Date().getTime();
                // 如果存储的时间在15秒内，设置忽略窗口
                if (currentTime - storedTimeNum < 15000) {
                    ignoreWebSocketErrorUntil = storedTimeNum + 15000;
                    isUpdatingLocation = true;
                } else {
                    // 超过15秒，清除标志
                    localStorage.removeItem('locationUpdating');
                    localStorage.removeItem('locationUpdateTime');
                }
            }
        } catch(e) {
            console.log('localStorage not available');
        }
    });
    
    if (phone !== 'cstp') {
        websocket.onopen = function () {
            console.log("websocket连接上");
            websocket.send(phone+","+me+",start");
        };
        websocket.onmessage = function (evnt) {
            // console.log(evnt.data);
            var result = evnt.data;
            if (result == "error"){
                // 已修改：在位置更新期间或忽略窗口内，忽略WebSocket错误
                // 同时检查localStorage中的标志，确保跨页面跳转时也能识别
                var currentTime = new Date().getTime();
                var currentPath = window.location.pathname;
                var isPersonalInfoPage = currentPath.indexOf('personal_info') > -1;
                var isLocationSettingsPage = currentPath.indexOf('location_settings') > -1;
                
                // 检查localStorage中的位置更新标志
                var locationUpdatingFromStorage = false;
                var locationUpdateTimeFromStorage = 0;
                try {
                    locationUpdatingFromStorage = localStorage.getItem('locationUpdating') === 'true';
                    var storedTime = localStorage.getItem('locationUpdateTime');
                    if (storedTime) {
                        locationUpdateTimeFromStorage = parseInt(storedTime);
                        // 如果存储的时间在15秒内，认为还在位置更新后的保护期内
                        if (currentTime - locationUpdateTimeFromStorage < 15000) {
                            locationUpdatingFromStorage = true;
                        } else {
                            // 超过15秒，清除标志
                            localStorage.removeItem('locationUpdating');
                            localStorage.removeItem('locationUpdateTime');
                        }
                    }
                } catch(e) {
                    console.log('localStorage not available');
                }
                
                if (isUpdatingLocation || currentTime < ignoreWebSocketErrorUntil || 
                    isPersonalInfoPage || isLocationSettingsPage || locationUpdatingFromStorage) {
                    console.log("位置更新中或相关页面，忽略WebSocket错误消息");
                    // 如果是个人信息页面或位置设置页面，延长忽略窗口，避免误判
                    if ((isPersonalInfoPage || isLocationSettingsPage) && currentTime < ignoreWebSocketErrorUntil) {
                        ignoreWebSocketErrorUntil = currentTime + 10000; // 再延长10秒
                    }
                    return;
                }
                window.location.href='/logout.do';
                alert("该账号在其他地方登录了，请检查是否为本人操作，防止密码丢失！！！");
                return;
            }
            setTimeout(function () {
                messageHandle();
            }, 2000);
        };
        websocket.onerror = function () {
            console.log("websocket错误");
        };
        websocket.onclose = function () {
            console.log("websocket关闭");
        };
        function messageHandle() {
            // alert(phone);
            websocket.send(phone+","+me+",send");
        };
    }
});
