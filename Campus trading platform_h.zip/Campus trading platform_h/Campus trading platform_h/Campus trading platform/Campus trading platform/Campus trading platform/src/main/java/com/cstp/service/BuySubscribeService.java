package com.cstp.service;

import java.util.List;

public interface BuySubscribeService {
    /**
     * 订阅某个分类的求购信息
     * @param userId 用户ID
     * @param categoryId 分类ID
     * @return 是否订阅成功
     */
    boolean subscribeCategory(Integer userId, Integer categoryId);

    /**
     * 取消订阅某个分类
     * @param userId 用户ID
     * @param categoryId 分类ID
     * @return 是否取消成功
     */
    boolean unsubscribeCategory(Integer userId, Integer categoryId);

    /**
     * 根据分类ID查询所有订阅该分类的用户ID列表
     * @param categoryId 分类ID
     * @return 用户ID列表
     */
    List<Integer> getUserIdsByCategoryId(Integer categoryId);

    /**
     * 根据用户ID查询所有订阅的分类ID列表
     * @param userId 用户ID
     * @return 分类ID列表
     */
    List<Integer> getCategoryIdsByUserId(Integer userId);
}
