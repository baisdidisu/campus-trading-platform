/**
 * 统一的位置管理工具
 * 用于在各个页面中统一管理用户位置信息
 */

var LocationManager = (function() {
    'use strict';

    // 私有变量
    var currentLocation = null;
    var apiBaseUrl = '/location';

    /**
     * 获取用户位置信息
     * @param {Function} successCallback - 成功回调函数
     * @param {Function} errorCallback - 失败回调函数
     */
    function getLocation(successCallback, errorCallback) {
        $.ajax({
            url: apiBaseUrl + '/get',
            type: 'GET',
            success: function(response) {
                // 已修改：兼容两种响应格式（response.code === 200 或 response.result === 1）
                var isSuccess = (response.code === 200) || (response.result === 1);
                if (isSuccess && response.data) {
                    currentLocation = response.data;
                    if (successCallback) {
                        successCallback(response.data);
                    }
                } else {
                    if (errorCallback) {
                        errorCallback(response.msg || response.message || '获取位置信息失败');
                    }
                }
            },
            error: function(xhr) {
                if (errorCallback) {
                    errorCallback('网络错误，请稍后重试');
                }
            }
        });
    }

    /**
     * 更新用户位置信息
     * @param {Object} locationData - 位置数据 {campus}
     * @param {Function} successCallback - 成功回调函数
     * @param {Function} errorCallback - 失败回调函数
     */
    function updateLocation(locationData, successCallback, errorCallback) {
        // 已修改：仅验证校区字段，移除楼栋验证
        if (!locationData.campus) {
            if (errorCallback) {
                errorCallback('请选择校区');
            }
            return;
        }
        // 已移除：楼栋验证
        // if (!locationData.building) {
        //     if (errorCallback) {
        //         errorCallback('请填写楼栋号');
        //     }
        //     return;
        // }

        // 已修改：在位置更新前设置标志，避免WebSocket误判为异地登录
        // 使用localStorage存储标志，确保跨页面也能生效
        if (window.setLocationUpdating) {
            window.setLocationUpdating(true);
        }
        // 同时在localStorage中存储时间戳，确保跨页面跳转时也能识别
        try {
            localStorage.setItem('locationUpdating', 'true');
            localStorage.setItem('locationUpdateTime', new Date().getTime().toString());
        } catch(e) {
            console.log('localStorage not available');
        }
        
        $.ajax({
            url: apiBaseUrl + '/update',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(locationData),
            success: function(response) {
                // 已修改：兼容两种响应格式（response.code === 200 或 response.result === 1）
                var isSuccess = (response.code === 200) || (response.result === 1);
                if (isSuccess) {
                    // 已修改：使用后端返回的数据，而不是前端传入的数据
                    // 后端返回的数据格式为 {campus: "xxx"}
                    if (response.data) {
                        currentLocation = response.data;
                    } else {
                        // 如果后端没有返回数据，使用前端传入的数据作为后备
                        currentLocation = locationData;
                    }
                    if (successCallback) {
                        successCallback(currentLocation);
                    }
                } else {
                    if (errorCallback) {
                        errorCallback(response.msg || response.message || '更新位置信息失败');
                    }
                }
                // 已修改：位置更新完成后，延迟清除标志（延长到15秒，确保页面跳转时不会被误判）
                if (window.setLocationUpdating) {
                    setTimeout(function() {
                        window.setLocationUpdating(false);
                    }, 15000);
                }
                // 更新localStorage中的时间戳
                try {
                    var updateTime = new Date().getTime();
                    localStorage.setItem('locationUpdateTime', updateTime.toString());
                    setTimeout(function() {
                        localStorage.removeItem('locationUpdating');
                        localStorage.removeItem('locationUpdateTime');
                    }, 15000);
                } catch(e) {
                    console.log('localStorage not available');
                }
            },
            error: function(xhr) {
                if (errorCallback) {
                    errorCallback('网络错误，请稍后重试');
                }
                // 已修改：即使更新失败，也要清除标志
                if (window.setLocationUpdating) {
                    setTimeout(function() {
                        window.setLocationUpdating(false);
                    }, 1000);
                }
                try {
                    localStorage.removeItem('locationUpdating');
                    localStorage.removeItem('locationUpdateTime');
                } catch(e) {
                    console.log('localStorage not available');
                }
            }
        });
    }

    /**
     * 格式化位置信息为字符串
     * @param {Object} location - 位置对象 {campus}
     * @returns {String} 格式化后的位置字符串
     */
    function formatLocation(location) {
        // 已修改：仅返回校区信息，移除楼栋和房间号
        if (!location || !location.campus) {
            return '未设置';
        }
        return location.campus;
        // 已移除：楼栋和房间号的格式化
        // var result = location.campus;
        // if (location.building) {
        //     result += ' ' + location.building;
        // }
        // if (location.room) {
        //     result += ' ' + location.room;
        // }
        // return result;
    }

    /**
     * 获取当前缓存的位置信息
     * @returns {Object|null} 位置对象或null
     */
    function getCurrentLocation() {
        return currentLocation;
    }

    /**
     * 填充位置表单
     * @param {String} campusSelector - 校区选择器
     * @param {String} buildingSelector - 楼栋输入框选择器
     * @param {String} roomSelector - 房间号输入框选择器
     */
    function fillLocationForm(campusSelector, buildingSelector, roomSelector) {
        getLocation(function(location) {
            if (campusSelector) {
                $(campusSelector).val(location.campus || '');
            }
            if (buildingSelector) {
                $(buildingSelector).val(location.building || '');
            }
            if (roomSelector) {
                $(roomSelector).val(location.room || '');
            }
        });
    }

    /**
     * 从表单获取位置数据
     * @param {String} campusSelector - 校区选择器
     * @param {String} buildingSelector - 楼栋输入框选择器
     * @param {String} roomSelector - 房间号输入框选择器
     * @returns {Object} 位置对象 {campus, building, room}
     */
    function getLocationFromForm(campusSelector, buildingSelector, roomSelector) {
        return {
            campus: $(campusSelector).val(),
            building: $(buildingSelector).val(),
            room: $(roomSelector).val()
        };
    }

    /**
     * 显示位置信息到指定元素
     * @param {String} selector - 元素选择器
     */
    function displayLocation(selector) {
        getLocation(function(location) {
            $(selector).text(formatLocation(location));
        }, function(error) {
            $(selector).text('未设置');
        });
    }

    // 公开的API
    return {
        get: getLocation,
        update: updateLocation,
        format: formatLocation,
        getCurrent: getCurrentLocation,
        fillForm: fillLocationForm,
        getFromForm: getLocationFromForm,
        display: displayLocation
    };
})();

// 兼容旧代码的全局函数
function loadUserLocation() {
    return LocationManager.get.apply(LocationManager, arguments);
}

function updateUserLocation(locationData, successCallback, errorCallback) {
    return LocationManager.update(locationData, successCallback, errorCallback);
}

