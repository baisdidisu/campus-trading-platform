package com.cstp.dao;

import com.cstp.pojo.ShopInformation;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

public interface ShopInformationMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ShopInformation record);

    int insertSelective(ShopInformation record);

    ShopInformation selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(ShopInformation record);

    int updateByPrimaryKey(ShopInformation record);

    List<ShopInformation> selectTen(Map map);

    List<ShopInformation> selectOffShelf(Integer uid, Integer start);

    int getCountsOffShelf(Integer uid);

    int getCounts();

    int selectIdByImage(String image);

    List<ShopInformation> selectByName(String name);

    //通过分类选择
    @Select("select * from shopinformation where sort=#{sort} and display =1 limit 12")
    List<ShopInformation> selectBySort(int sort);

    //选择用户的发布
    @Select("select * from shopinformation where uid=#{uid} and display=1 order by id desc limit 12")
    List<ShopInformation> selectUserReleaseByUid(int uid);

    //查询所有商品
    @Select("select * from shopinformation where display=1 order by modified desc")
    List<ShopInformation> selectAll();
    /**
     * 根据分类统计成交订单的价格（MIN, MAX, AVG）
     * 通过goodsoforderform关联shopinformation获取价格
     */
    Map<String, Object> selectPriceStatisticsBySort(Integer sort);

    /**
     * 查询发布超过指定天数的商品
     * @param days 天数
     * @return 过期商品列表
     */
    List<ShopInformation> selectExpiredGoods(Integer days);
    
    /**
     * 多条件筛选商品
     * @param params 筛选条件
     * @return 符合条件的商品列表
     */
    List<ShopInformation> selectByMultiCondition(Map<String, Object> params);
    
    /**
     * 获取多条件筛选的商品总数
     * @param params 筛选条件
     * @return 符合条件的商品总数
     */
    int countByMultiCondition(Map<String, Object> params);
}