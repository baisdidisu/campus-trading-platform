package com.cstp.service.Impl;

import com.cstp.dao.OrderOperationLogMapper;
import com.cstp.pojo.OrderOperationLog;
import com.cstp.service.OrderOperationLogService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class OrderOperationLogServiceImpl implements OrderOperationLogService {

    @Resource
    private OrderOperationLogMapper orderOperationLogMapper;

    @Override
    public int insert(OrderOperationLog record) {
        return orderOperationLogMapper.insert(record);
    }

    @Override
    public int insertSelective(OrderOperationLog record) {
        return orderOperationLogMapper.insertSelective(record);
    }

    @Override
    public OrderOperationLog selectByPrimaryKey(Integer id) {
        return orderOperationLogMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<OrderOperationLog> selectByOrderId(Integer orderId) {
        return orderOperationLogMapper.selectByOrderId(orderId);
    }

    @Override
    public void logOperation(Integer orderId, Integer operatorId, String operationType, String operationDesc) {
        OrderOperationLog log = new OrderOperationLog();
        log.setOrderId(orderId);
        log.setOperatorId(operatorId);
        log.setOperationType(operationType);
        log.setOperationDesc(operationDesc);
        log.setCreatedTime(new Date());
        orderOperationLogMapper.insertSelective(log);
    }
}

