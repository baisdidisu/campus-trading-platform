package com.cstp.controller;

import com.cstp.pojo.UserInformation;
import com.cstp.response.BaseResponse;
import com.cstp.service.UserInformationService;
import com.cstp.tool.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Random;

@Controller
public class SendEmailController {

    @Resource
    private UserInformationService userInformationService;
    private static final Logger log = LoggerFactory.getLogger(SendEmailController.class);

    //send the Email to the phone
    @RequestMapping(value = "sendCode.do", method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public BaseResponse sendEmail(HttpServletRequest req, HttpServletResponse res,
                                  @RequestParam String phone, @RequestParam String action,
                                  @RequestParam String token) {
        res.setContentType("text/html;charset=UTF-8");

        // ✅ 1. token防重复提交校验（注意：此处仅校验，不销毁token，因为后续checkCode.do还需要使用）
        String sendCodeToken = (String) req.getSession().getAttribute("token");
        if (StringUtils.getInstance().isNullOrEmpty(sendCodeToken) || !sendCodeToken.equals(token)) {
            log.warn("⚠️ 发送验证码失败：token验证失败");
            return BaseResponse.fail("请勿重复提交");
        }
        // 注意：此处不销毁token，因为用户后续还需要用token进行验证码校验（checkCode.do）

        // ✅ 2. 手机号格式校验
        if (StringUtils.getInstance().isNullOrEmpty(phone)) {
            log.warn("⚠️ 发送验证码失败：手机号为空");
            return BaseResponse.fail(0); // ✅ 一比一复刻：返回0表示手机号格式错误
        }
        if (!StringUtils.getInstance().isPhone(phone)) {
            log.warn("⚠️ 发送验证码失败：手机号格式错误，phone={}", phone);
            return BaseResponse.fail(0); // ✅ 一比一复刻：返回0表示手机号格式错误
        }

        // ✅ 3. action参数校验
        if (StringUtils.getInstance().isNullOrEmpty(action)) {
            log.warn("⚠️ 发送验证码失败：action参数为空");
            return BaseResponse.fail("参数错误");
        }

        // ✅ 4. 注册/找回密码 手机号存在性校验
        if ("forget".equals(action)) {
            if (!isUserPhoneExists(phone)) {
                log.warn("⚠️ 发送验证码失败：手机号未注册，phone={}", phone);
                return BaseResponse.fail(-1); // ✅ 一比一复刻：返回-1表示手机号未注册
            }
        } else if ("register".equals(action)) {
            if (isUserPhoneExists(phone)) {
                log.warn("⚠️ 发送验证码失败：手机号已注册，phone={}", phone);
                return BaseResponse.fail(-1); // ✅ 一比一复刻：返回-1表示手机号已注册
            }
        } else {
            log.warn("⚠️ 发送验证码失败：action参数错误，action={}", action);
            return BaseResponse.fail("参数错误");
        }

        // ✅ 5. 防频繁发送（60秒限制）- 修复原代码【未设置时间戳】的BUG，现在真正生效
        Long lastSendTime = (Long) req.getSession().getAttribute("lastSendCodeTime");
        long currentTime = System.currentTimeMillis();
        if (lastSendTime != null && (currentTime - lastSendTime) / 1000 < 60) {
            long waitTime = 60 - (currentTime - lastSendTime) / 1000;
            log.warn("⚠️ 发送验证码失败：发送过于频繁，需等待{}秒", waitTime);
            return BaseResponse.fail("发送过于频繁，请" + waitTime + "秒后再试");
        }
        req.getSession().setAttribute("lastSendCodeTime", currentTime); // 核心：记录本次发送时间

        // ✅ 6. 生成验证码 + 修复【大小写不一致】BUG（前后端统一为原始值，不转小写）
        String code = getRandomForCodePhone(req);
        try {
            // 存储手机号和验证码到session（供后续校验使用）
            req.getSession().setAttribute("phone", phone);
            // ✅ 记录发送时间
            req.getSession().setAttribute("lastSendCodeTime", System.currentTimeMillis());
            log.info("✅ 验证码生成成功，phone={}, code={}", phone, code);

            // ✅ 核心根治：返回【验证码在data字段】的响应，前端直接弹窗显示
            // 🔥 将验证码放在data字段，msg留空，前端alert(res.data)只显示纯验证码
            return new BaseResponse(1, "", code);
        } catch (Exception me) {
            log.error("❌ 生成验证码异常", me);
            return BaseResponse.fail("生成失败，请稍后重试");
        }
    }

    // ✅ 重构验证码生成方法 - 修复【转小写导致验证失败】的致命BUG，返回原始验证码
    private String getRandomForCodePhone(HttpServletRequest req) {
        Random random = new Random();
        // 可选：纯数字验证码（更符合用户习惯，也可保留原字母+数字）
        String chars = "0123456789";
        // 如需保留原规则（字母+数字），启用下面这行 ↓
        // String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        String code = sb.toString();
        log.info("短信验证码={}", code);
        System.out.println(code);

        // ✅ 核心：存储【原始验证码】，不转小写！前后端校验完全一致，避免验证失败
        req.getSession().setAttribute("codePhone", code);
        return code; // 返回生成的验证码
    }

    //To determine whether the user's mobile phone number exists
    private boolean isUserPhoneExists(String phone) {
        try {
            int id = userInformationService.selectIdByPhone(phone);
            if (id == 0) return false;

            UserInformation userInformation = userInformationService.selectByPrimaryKey(id);
            return userInformation != null && !StringUtils.getInstance().isNullOrEmpty(userInformation.getPhone());
        } catch (Exception e) {
            log.error("❌ 校验手机号是否存在异常", e);
            return false;
        }
    }
}//已修改
