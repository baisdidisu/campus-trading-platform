package com.cstp.service;

import java.util.List;

public interface MallSubscribeService {
    /**
     * 订阅某个分类的商品信息
     */
    boolean subscribeCategory(Integer userId, Integer categoryId);

    /**
     * 取消订阅某个分类
     */
    boolean unsubscribeCategory(Integer userId, Integer categoryId);

    /**
     * 根据分类ID查询所有订阅该分类的用户ID列表
     */
    List<Integer> getUserIdsByCategoryId(Integer categoryId);

    /**
     * 根据用户ID查询所有订阅的分类ID列表
     */
    List<Integer> getCategoryIdsByUserId(Integer userId);
}

