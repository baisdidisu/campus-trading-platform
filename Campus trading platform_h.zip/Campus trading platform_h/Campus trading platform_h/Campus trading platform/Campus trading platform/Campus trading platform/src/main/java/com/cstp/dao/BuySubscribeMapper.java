package com.cstp.dao;

import com.cstp.pojo.BuySubscribe;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BuySubscribeMapper {
    int deleteByPrimaryKey(Integer subscribeId);

    int insert(BuySubscribe record);

    int insertSelective(BuySubscribe record);

    BuySubscribe selectByPrimaryKey(Integer subscribeId);

    int updateByPrimaryKeySelective(BuySubscribe record);

    int updateByPrimaryKey(BuySubscribe record);

    /**
     * 根据用户ID和分类ID查询订阅
     * @param userId 用户ID
     * @param categoryId 分类ID
     * @return 订阅信息
     */
    BuySubscribe selectByUserIdAndCategoryId(@Param("userId") Integer userId, 
                                             @Param("categoryId") Integer categoryId);

    /**
     * 根据用户ID和分类ID查询订阅（包含 display=0 的历史记录）
     */
    BuySubscribe selectAnyByUserIdAndCategoryId(@Param("userId") Integer userId,
                                               @Param("categoryId") Integer categoryId);

    /**
     * 仅更新 display/modified，避免更新 user_id/category_id 触发唯一索引冲突
     */
    int updateDisplayByPrimaryKey(BuySubscribe record);

    /**
     * 根据分类ID查询所有订阅该分类的用户ID列表
     * @param categoryId 分类ID
     * @return 用户ID列表
     */
    List<Integer> selectUserIdsByCategoryId(@Param("categoryId") Integer categoryId);

    /**
     * 根据用户ID查询所有订阅的分类ID列表
     * @param userId 用户ID
     * @return 分类ID列表
     */
    List<Integer> selectCategoryIdsByUserId(@Param("userId") Integer userId);
}

