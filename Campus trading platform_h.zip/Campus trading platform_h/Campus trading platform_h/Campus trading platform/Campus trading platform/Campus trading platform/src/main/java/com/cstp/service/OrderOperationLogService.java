package com.cstp.service;

import com.cstp.pojo.OrderOperationLog;

import java.util.List;

public interface OrderOperationLogService {
    int insert(OrderOperationLog record);

    int insertSelective(OrderOperationLog record);

    OrderOperationLog selectByPrimaryKey(Integer id);

    List<OrderOperationLog> selectByOrderId(Integer orderId);

    /**
     * 记录订单操作日志
     */
    void logOperation(Integer orderId, Integer operatorId, String operationType, String operationDesc);
}

