package com.cstp.service;

import com.cstp.pojo.OrderReminder;

import java.util.List;

public interface OrderReminderService {
    int insert(OrderReminder record);

    int insertSelective(OrderReminder record);

    OrderReminder selectByPrimaryKey(Integer id);

    List<OrderReminder> selectPendingReminders();

    int updateByPrimaryKeySelective(OrderReminder record);

    int markAsSent(Integer id);

    /**
     * 为订单创建提醒
     */
    void createRemindersForOrder(Integer orderId, Integer userId);
}

