package com.cstp.schedule;

import com.cstp.service.MessageReminderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Slf4j
public class MessageReminderSchedule {

    @Resource
    private MessageReminderService messageReminderService;

    /**
     * 每日凌晨2点执行一次，查询发布超过30天的商品，推送过期提醒
     * cron表达式：秒 分 时 日 月 周
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void notifyExpiredGoods() {
        log.info("开始执行过期商品提醒定时任务");
        try {
            int count = messageReminderService.notifyExpiredGoods();
            log.info("过期商品提醒定时任务执行完成，共发送{}条消息", count);
        } catch (Exception e) {
            log.error("过期商品提醒定时任务执行失败", e);
        }
    }
}

