package com.cstp.dao;

import com.cstp.pojo.OrderReminder;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderReminderMapper {
    int insert(OrderReminder record);

    int insertSelective(OrderReminder record);

    OrderReminder selectByPrimaryKey(Integer id);

    List<OrderReminder> selectPendingReminders();

    int updateByPrimaryKeySelective(OrderReminder record);

    int markAsSent(@Param("id") Integer id);
}

