package com.cstp.service;

import com.cstp.pojo.ShopInformation;

public interface MallMatchService {
    /**
     * 当商品发布成功后，向订阅了该分类的用户发送提醒消息
     * @param shopInfo 发布的商品信息
     * @return 发送消息的数量
     */
    int notifySubscribedUsers(ShopInformation shopInfo);
}

