package com.cstp.dao;

import com.cstp.pojo.MallSubscribe;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface MallSubscribeMapper {
    int deleteByPrimaryKey(Integer subscribeId);

    int insert(MallSubscribe record);

    int insertSelective(MallSubscribe record);

    MallSubscribe selectByPrimaryKey(Integer subscribeId);

    int updateByPrimaryKeySelective(MallSubscribe record);

    int updateByPrimaryKey(MallSubscribe record);

    /**
     * 根据用户ID和分类ID查询订阅
     */
    MallSubscribe selectByUserIdAndCategoryId(@Param("userId") Integer userId,
                                            @Param("categoryId") Integer categoryId);

    /**
     * 根据分类ID查询所有订阅该分类的用户ID列表
     */
    List<Integer> selectUserIdsByCategoryId(@Param("categoryId") Integer categoryId);

    /**
     * 根据用户ID查询所有订阅的分类ID列表
     */
    List<Integer> selectCategoryIdsByUserId(@Param("userId") Integer userId);
}

