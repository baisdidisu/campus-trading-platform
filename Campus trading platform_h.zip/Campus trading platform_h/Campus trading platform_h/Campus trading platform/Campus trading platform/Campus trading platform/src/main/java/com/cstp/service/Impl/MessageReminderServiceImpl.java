package com.cstp.service.Impl;

import com.cstp.dao.ShopInformationMapper;
import com.cstp.dao.UserCollectionMapper;
import com.cstp.pojo.Message;
import com.cstp.pojo.ShopInformation;
import com.cstp.service.MessageReminderService;
import com.cstp.service.MessageService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class MessageReminderServiceImpl implements MessageReminderService {

    @Resource
    private UserCollectionMapper userCollectionMapper;

    @Resource
    private ShopInformationMapper shopInformationMapper;

    @Resource
    private MessageService messageService;

    @Override
    public int notifyPriceDrop(Integer shopId, Double oldPrice, Double newPrice) {
        int notifyCount = 0;
        
        try {
            // 查询收藏该商品的所有用户ID
            List<Integer> userIds = userCollectionMapper.selectUserIdsBySid(shopId);
            
            // 获取商品信息
            ShopInformation shopInfo = shopInformationMapper.selectByPrimaryKey(shopId);
            if (shopInfo == null) {
                return 0;
            }
            
            // 向每个收藏用户发送降价提醒
            for (Integer userId : userIds) {
                // 排除商品发布者自己
                if (!userId.equals(shopInfo.getUid())) {
                    Message message = new Message();
                    message.setFromUserId(shopInfo.getUid()); // 商品发布者
                    message.setToUserId(userId);
                    message.setContent(String.format("您收藏的商品【%s】降价了！原价：%.2f元，现价：%.2f元，降价：%.2f元", 
                        shopInfo.getName(), oldPrice, newPrice, oldPrice - newPrice));
                    message.setMessageType(2); // 价格提醒
                    message.setRelatedId(shopId);
                    message.setModified(new Date());
                    message.setIsRead(0);
                    message.setDisplay(1);
                    
                    messageService.sendMessage(message);
                    notifyCount++;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return notifyCount;
    }

    @Override
    public int notifyExpiredGoods() {
        int notifyCount = 0;
        
        try {
            // 查询发布超过30天的商品
            List<ShopInformation> expiredGoods = shopInformationMapper.selectExpiredGoods(30);
            
            // 向商品发布者发送过期提醒
            for (ShopInformation shopInfo : expiredGoods) {
                Message message = new Message();
                message.setFromUserId(0); // 系统消息
                message.setToUserId(shopInfo.getUid());
                message.setContent(String.format("您发布的商品【%s】已发布超过30天，建议及时更新或下架", shopInfo.getName()));
                message.setMessageType(3); // 过期提醒
                message.setRelatedId(shopInfo.getId());
                message.setModified(new Date());
                message.setIsRead(0);
                message.setDisplay(1);
                
                messageService.sendMessage(message);
                notifyCount++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return notifyCount;
    }
}
