package com.cstp.dao;

import com.cstp.pojo.UserWant;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserWantMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(UserWant record);

    int insertSelective(UserWant record);

    UserWant selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(UserWant record);

    int updateByPrimaryKey(UserWant record);

    int getCounts(int uid);

    List<UserWant> selectByUid(int uid, int start);

    @Select("select * from userwant where uid=#{id} and display=1 order by id desc limit 12")
    List<UserWant> selectMineByUid(int id);

    List<UserWant> selectAll();

    /**
     * 根据商品名称（模糊匹配）和分类ID查询求购信息
     * @param name 商品名称（用于LIKE查询）
     * @param sort 分类ID
     * @return 匹配的求购信息列表
     */
    List<UserWant> selectByNameAndSort(@Param("name") String name, @Param("sort") Integer sort);
}