package com.cstp.controller;

import com.cstp.pojo.UserInformation;
import com.cstp.pojo.UserPassword;
import com.cstp.response.BaseResponse;
import com.cstp.service.UserInformationService;
import com.cstp.service.UserPasswordService;
import com.cstp.tool.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Controller
@Slf4j
public class RegisterController {
    @Resource
    private UserPasswordService userPasswordService;

    @Resource
    private UserInformationService userInformationService;

    //开始注册用户
    @RequestMapping("/insertUser.do")
    @ResponseBody
    public BaseResponse insertUser(HttpServletRequest request,
                                   @RequestParam String password, @RequestParam String token,
                                   @RequestParam String code) {
        //存储与session中的手机号码
        String realPhone = (String) request.getSession().getAttribute("phone");
        //token，唯一标识
        String insertUserToken = (String) request.getSession().getAttribute("token");
        
        // ✅ 防止重复提交 - token校验优化
        if (StringUtils.getInstance().isNullOrEmpty(insertUserToken) || !insertUserToken.equals(token)) {
            log.warn("⚠️ 注册失败：token验证失败，可能是重复提交");
            return BaseResponse.fail("请勿重复提交");
        }
        
        // ✅ 验证手机号是否存在于session
        if (StringUtils.getInstance().isNullOrEmpty(realPhone)) {
            log.warn("⚠️ 注册失败：session中未找到手机号");
            return BaseResponse.fail("会话已过期，请重新获取验证码");
        }
        
        // ✅ 验证码校验 - 核心验证
        String sessionCode = (String) request.getSession().getAttribute("codePhone");
        if (StringUtils.getInstance().isNullOrEmpty(sessionCode)) {
            log.warn("⚠️ 注册失败：session中未找到验证码");
            return BaseResponse.fail("验证码已过期，请重新获取");
        }
        if (!sessionCode.equals(code.toLowerCase())) {
            log.warn("⚠️ 注册失败：验证码错误，输入={}, 正确={}", code, sessionCode);
            return BaseResponse.fail("验证码错误");
        }
        
        // ✅ 验证密码格式
        if (StringUtils.getInstance().isNullOrEmpty(password) || password.length() < 6) {
            log.warn("⚠️ 注册失败：密码格式不正确");
            return BaseResponse.fail("密码长度至少6位");
        }
        
        //该手机号码已经存在
        int uid = userInformationService.selectIdByPhone(realPhone);
        if (uid != 0) {
            log.warn("⚠️ 注册失败：手机号已存在，phone={}", realPhone);
            return BaseResponse.fail("该手机号已注册");
        }

        //用户信息
        UserInformation userInformation = new UserInformation();
        userInformation.setPhone(realPhone);
        userInformation.setCreatetime(new Date());
        String username = (String) request.getSession().getAttribute("name");
        userInformation.setUsername(username);
        userInformation.setModified(new Date());
        int result;
        result = userInformationService.insertSelective(userInformation);
        //如果用户基本信息写入成功
        if (result == 1) {
            uid = userInformationService.selectIdByPhone(realPhone);
            String newPassword = StringUtils.getInstance().getMD5(password);
            UserPassword userPassword = new UserPassword();
            userPassword.setModified(new Date());
            userPassword.setUid(uid);
            userPassword.setPassword(newPassword);
            result = userPasswordService.insertSelective(userPassword);
            //密码写入失败
            if (result != 1) {
                userInformationService.deleteByPrimaryKey(uid);
                log.error("❌ 注册失败：密码写入失败，已回滚用户信息");
                return BaseResponse.fail("注册失败，请重试");
            } else {
                //注册成功
                userInformation = userInformationService.selectByPrimaryKey(uid);
                request.getSession().setAttribute("userInformation", userInformation);
                request.getSession().setAttribute("uid", uid);
                // ✅ 注册成功后移除token，防止重复提交
                request.getSession().removeAttribute("token");
                log.info("✅ 用户注册成功，phone={}, uid={}", realPhone, uid);
                return BaseResponse.success("注册成功");
            }
        }
        log.error("❌ 注册失败：用户信息写入失败");
        return BaseResponse.fail("注册失败，请重试");
    }
}//已修改

