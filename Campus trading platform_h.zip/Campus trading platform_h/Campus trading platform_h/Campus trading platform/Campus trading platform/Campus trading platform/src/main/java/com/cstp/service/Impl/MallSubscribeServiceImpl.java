package com.cstp.service.Impl;

import com.cstp.dao.MallSubscribeMapper;
import com.cstp.pojo.MallSubscribe;
import com.cstp.service.MallSubscribeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
public class MallSubscribeServiceImpl implements MallSubscribeService {

    @Resource
    private MallSubscribeMapper mallSubscribeMapper;

    @Override
    public boolean subscribeCategory(Integer userId, Integer categoryId) {
        try {
            // 检查是否已经订阅
            MallSubscribe existing = mallSubscribeMapper.selectByUserIdAndCategoryId(userId, categoryId);
            if (existing != null) {
                // 如果已存在但被取消，则重新激活
                if (existing.getDisplay() == 0) {
                    existing.setDisplay(1);
                    existing.setModified(new Date());
                    return mallSubscribeMapper.updateByPrimaryKeySelective(existing) > 0;
                }
                // 如果已存在且有效，提示已订阅
                return false;
            }

            // 创建新订阅
            MallSubscribe subscribe = new MallSubscribe();
            subscribe.setUserId(userId);
            subscribe.setCategoryId(categoryId);
            subscribe.setModified(new Date());
            subscribe.setDisplay(1);

            return mallSubscribeMapper.insertSelective(subscribe) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean unsubscribeCategory(Integer userId, Integer categoryId) {
        try {
            MallSubscribe subscribe = mallSubscribeMapper.selectByUserIdAndCategoryId(userId, categoryId);
            if (subscribe == null) {
                return false;
            }

            // 软删除：设置display为0
            subscribe.setDisplay(0);
            subscribe.setModified(new Date());
            return mallSubscribeMapper.updateByPrimaryKeySelective(subscribe) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Integer> getUserIdsByCategoryId(Integer categoryId) {
        try {
            return mallSubscribeMapper.selectUserIdsByCategoryId(categoryId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Integer> getCategoryIdsByUserId(Integer userId) {
        try {
            return mallSubscribeMapper.selectCategoryIdsByUserId(userId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

